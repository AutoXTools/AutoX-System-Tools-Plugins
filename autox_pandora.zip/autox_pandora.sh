#!/bin/sh
# ==============================================================================
# AutoX Application Runner Framework Plugin - Standard Target Module
# ==============================================================================
# Target Platform: Mazda Connect CMU FW 74.00.324 ONLY
# Architecture: ARMv7 / i.MX6 Dual/Quad SoC
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

# --------------------------------------------------------------------------
# COMPILER BUILD DIRECTIVES (Non-Runtime Comments)
# --------------------------------------------------------------------------
# @directive hook_placement: custom
# @directive hook_placement_logic: In-place line swap via /tmp-staged single-pass awk; every anchor line is replaced by an id-pinned hook holding the OEM line (XML: %25/%2D-encoded) as an "AutoX pandora OEM:" comment plus its patched form, with exact per-anchor match counts: sm.conf + sm_WCP.conf name="blm_ira_pandora" x1 and name="irs_server" x1 (autorun="yes" -> autorun="no"); mmui_config.xml uiaid="10" name="pandora" x1 (OEM line commented out); GuiResources.js "pandora": true x1 (true -> false); abort and roll back on any count mismatch.

TITLE="Disable Pandora Service"
SUBTITLE="Improved system bootup experience"
ID="pandora"
NAME="PANDORA"
AUTHOR="AutoX"
CATEGORY="tweak"
ORDER=50
SHOW_IN_GUI="true"
VERSION="0.11"
INSTALL_STATE="disabled"
REBOOT_REQUIRED="true"
LONG_PRESS="false"

AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"

FLAG="$ENABLED_DIR/${ID}_enabled"
LOCK_FILE="/tmp/autox_${ID}.lock"
PLUGIN_TARGET="$PLUGINS_DIR/autox_${ID}.sh"
SCRIPT_PATH=$(readlink -f "$0" 2>/dev/null)
[ -z "$SCRIPT_PATH" ] && SCRIPT_PATH="$0"

FW_INI="/jci/version.ini"
FW_REQUIRED="74.00.324"

GUIRES_JS="/jci/gui/resources/js/GuiResources.js"
SM_CONF="/jci/sm/sm.conf"
SM_WCP_CONF="/jci/sm/sm_WCP.conf"
MMUI_XML="/jci/mmui/mmui_config.xml"

TMP_INS="/tmp/autox_${ID}_ins.tmp"
TMP_FILE="/tmp/autox_${ID}_rm.tmp"

. /tmp/mnt/data_persist/autox/lib/autox_lib.sh

# --------------------------------------------------------------------------
# Summary: Check Firmware Routine
# --------------------------------------------------------------------------
check_firmware() {
    if [ ! -f "$FW_INI" ]; then
        autox_log "$ID" "[ERROR] Missing $FW_INI; cannot verify firmware $FW_REQUIRED."
        return 1
    fi
    if ! grep -q '^JCI_SW_VER="[^"]*_74\.00\.324"' "$FW_INI" 2>/dev/null; then
        autox_log "$ID" "[ERROR] Firmware is not $FW_REQUIRED ($(grep '^JCI_SW_VER=' "$FW_INI" 2>/dev/null)); aborting."
        return 1
    fi
    return 0
}

# --------------------------------------------------------------------------
# Summary: Hook Tokens Routine
# --------------------------------------------------------------------------
hook_tokens() {
    if [ "$1" = "xml" ]; then
        _CO="<!--"
        _CC=" -->"
    else
        _CO="//"
        _CC=""
    fi
    _MS="$_CO === AutoX pandora Insertion Hook ==="
    _ME="$_CO === AutoX pandora Insertion Hook End ==="
    _OP="$_CO AutoX pandora OEM: "
}

# --------------------------------------------------------------------------
# Summary: Strip File Routine
# --------------------------------------------------------------------------
strip_file() {
    _SF_TARGET="$1"
    hook_tokens "$2"
    [ -s "$_SF_TARGET" ] || return 0
    _SF_START=$(grep -cF "$_MS" "$_SF_TARGET" 2>/dev/null)
    [ -z "$_SF_START" ] && _SF_START=0
    [ "$_SF_START" -eq 0 ] && return 0
    _SF_END=$(grep -cF "$_ME" "$_SF_TARGET" 2>/dev/null)
    [ -z "$_SF_END" ] && _SF_END=0
    if [ "$_SF_START" -ne "$_SF_END" ]; then
        autox_log "$ID" "[ERROR] Unbalanced pandora hook markers in $_SF_TARGET ($_SF_START start / $_SF_END end); aborting teardown."
        return 1
    fi
    awk -v ms="$_MS" -v me="$_ME" -v op="$_OP" -v cc="$_CC" '
    function dec(s) {
        if (cc != "") { gsub(/%2D/, "-", s); gsub(/%25/, "%", s) }
        return s
    }
    function out(l) {
        if (l ~ /^[ \t\r]*$/) { buf = buf l "\n" } else { printf "%s%s\n", buf, l; buf = "" }
    }
    BEGIN { inb = 0; buf = "" }
    !inb && index($0, ms) > 0 { inb = 1; next }
    inb && index($0, me) > 0 { inb = 0; next }
    inb {
        if (index($0, op) == 1) {
            s = substr($0, length(op) + 1)
            n = length(s) - length(cc)
            if (cc != "" && n >= 0 && substr(s, n + 1) == cc) s = substr(s, 1, n)
            out(dec(s))
        }
        next
    }
    { out($0) }
    END { if (inb) exit 2 }
    ' "$_SF_TARGET" > "$TMP_FILE" 2>/dev/null
    if [ $? -eq 0 ] && [ -s "$TMP_FILE" ]; then
        cp -f "$TMP_FILE" "$_SF_TARGET"
        rm -f "$TMP_FILE"
        autox_log "$ID" "[HOOK] Restored OEM lines & removed pandora hook(s) from $_SF_TARGET"
    else
        rm -f "$TMP_FILE"
        autox_log "$ID" "[ERROR] Failed staging clean $_SF_TARGET in /tmp"
        return 1
    fi
    return 0
}

# --------------------------------------------------------------------------
# Summary: Insert File Routine
# --------------------------------------------------------------------------
insert_file() {
    _IF_TARGET="$1"
    hook_tokens "$2"
    _IF_EXPECT="$3"
    shift 3
    if [ ! -f "$_IF_TARGET" ]; then
        autox_log "$ID" "[ERROR] Missing target file $_IF_TARGET"
        return 1
    fi
    awk -v ver="v${VERSION#v}" -v co="$_CO" -v cc="$_CC" \
        -v a1="$1" -v f1="$2" -v t1="$3" -v n1="$4" \
        -v a2="$5" -v f2="$6" -v t2="$7" -v n2="$8" '
    function enc(s) {
        if (cc != "") { gsub(/%/, "%25", s); gsub(/-/, "%2D", s) }
        return s
    }
    function swap(line, from, to,    p, k, i, parts) {
        print co " === AutoX pandora Insertion Hook === " ver cc
        print co " AutoX pandora OEM: " enc(line) cc
        if (from != "") {
            p = index(line, from)
            if (p == 0) {
                bad = 1
            } else {
                k = split(to, parts, "|")
                for (i = 1; i <= k; i++) print substr(line, 1, p - 1) parts[i] substr(line, p + length(from))
            }
        }
        print co " === AutoX pandora Insertion Hook End ===" cc
    }
    BEGIN { c1 = 0; c2 = 0; bad = 0 }
    a1 != "" && index($0, a1) > 0 { swap($0, f1, t1); c1++; next }
    a2 != "" && index($0, a2) > 0 { swap($0, f2, t2); c2++; next }
    { print }
    END {
        if (bad) exit 3
        if (a1 != "" && c1 != n1 + 0) exit 1
        if (a2 != "" && c2 != n2 + 0) exit 1
    }
    ' "$_IF_TARGET" > "$TMP_INS" 2>/dev/null
    _IF_RC=$?
    if [ $_IF_RC -ne 0 ] || [ ! -s "$TMP_INS" ]; then
        rm -f "$TMP_INS"
        autox_log "$ID" "[ERROR] Anchor missing, count mismatch or unpatchable line in $_IF_TARGET (awk rc=$_IF_RC); not modified."
        return 1
    fi
    if ! cp -f "$TMP_INS" "$_IF_TARGET"; then
        rm -f "$TMP_INS"
        autox_log "$ID" "[ERROR] Failed writing patched $_IF_TARGET"
        return 1
    fi
    rm -f "$TMP_INS"
    _IF_START=$(grep -cF "$_MS" "$_IF_TARGET" 2>/dev/null)
    _IF_END=$(grep -cF "$_ME" "$_IF_TARGET" 2>/dev/null)
    if [ "$_IF_START" != "$_IF_EXPECT" ] || [ "$_IF_END" != "$_IF_EXPECT" ]; then
        autox_log "$ID" "[ERROR] Hook verification failed in $_IF_TARGET (start=$_IF_START end=$_IF_END expected=$_IF_EXPECT)"
        return 1
    fi
    autox_log "$ID" "[HOOK] Injected $_IF_EXPECT pandora hook(s) into $_IF_TARGET"
    return 0
}

# --------------------------------------------------------------------------
# Summary: Patch Sm Routine
# --------------------------------------------------------------------------
patch_sm() {
    insert_file "$1" xml 2 \
        'name="blm_ira_pandora"' 'autorun="yes"' 'autorun="no"' 1 \
        'name="irs_server"' 'autorun="yes"' 'autorun="no"' 1
}

# --------------------------------------------------------------------------
# Summary: Enable Abort Routine
# --------------------------------------------------------------------------
enable_abort() {
    remove_hooks
    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    autox_log "$ID" "[ERROR] Enabling $TITLE failed; OEM files rolled back."
    return 1
}

# --------------------------------------------------------------------------
# Summary: Runtime Execution State Query (Returns "ENABLED" | "DISABLED")
# --------------------------------------------------------------------------
get_status() {
    if [ -f "$FLAG" ]; then echo "ENABLED"; else echo "DISABLED"; fi
}

# --------------------------------------------------------------------------
# Summary: First-Run Deployment Routine (NAND Staging & Permission Hardening)
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    autox_log "$ID" "[START] $TITLE v$VERSION Installation Initiated"
    if ! check_firmware; then
        release_lock
        return 1
    fi
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR" 2>/dev/null
    autox_log "$ID" "[COMPLETED] $TITLE v$VERSION successfully deployed."
    release_lock
}

# --------------------------------------------------------------------------
# Summary: In-Place Upgrade Handler (Version Matching & Safe State Preservation)
# --------------------------------------------------------------------------
do_reinstall() {
    FORCE=0
    [ "$1" = "--force" ] || [ "$2" = "--force" ] && FORCE=1

    if [ "$SCRIPT_PATH" = "$PLUGIN_TARGET" ]; then
        autox_log "$ID" "[ERROR] Cannot reinstall directly from installed target path $PLUGIN_TARGET."
        return 1
    fi

    CUR_VER="0"
    if [ -f "$PLUGIN_TARGET" ]; then
        CUR_VER=$("/bin/sh" "$PLUGIN_TARGET" version 2>/dev/null)
        [ -z "$CUR_VER" ] && CUR_VER="0"
    fi
    if [ "$CUR_VER" = "$VERSION" ] && [ $FORCE -eq 0 ]; then
        autox_log "$ID" "[SKIP] $ID already at v$VERSION. Skipping in-place rewrite."
        return 0
    fi

    WAS_ENABLED=0
    [ -f "$FLAG" ] && WAS_ENABLED=1

    if [ -f "$PLUGIN_TARGET" ]; then
        if ! /bin/sh "$PLUGIN_TARGET" disable; then
            autox_log "$ID" "[ERROR] Failed disabling prior $ID hooks prior to upgrade."
            return 1
        fi
    fi

    if ! cmu_verify_persist_rw; then
        autox_log "$ID" "[ERROR] Persistent flash /tmp/mnt/data_persist is not writable."
        return 1
    fi

    if ! cp -f "$SCRIPT_PATH" "$PLUGIN_TARGET"; then
        autox_log "$ID" "[ERROR] Failed copying $SCRIPT_PATH to $PLUGIN_TARGET."
        return 1
    fi
    chmod 755 "$PLUGIN_TARGET" 2>/dev/null
    sync

    if ! /bin/sh "$PLUGIN_TARGET" install; then
        autox_log "$ID" "[ERROR] Failed installing upgraded $ID payload."
        return 1
    fi

    if [ $WAS_ENABLED -eq 1 ]; then
        if ! /bin/sh "$PLUGIN_TARGET" enable --staged; then
            autox_log "$ID" "[ERROR] Upgraded $ID failed staged re-enable."
            return 1
        fi
    fi
    autox_log "$ID" "[REINSTALL] Successfully updated $ID to v$VERSION."
}

# --------------------------------------------------------------------------
# Summary: Remove Hooks Routine
# --------------------------------------------------------------------------
remove_hooks() {
    _RH_RC=0
    if ! strip_file "$GUIRES_JS" js; then
        _RH_RC=1
    fi
    if ! strip_file "$SM_CONF" xml; then
        _RH_RC=1
    fi
    if ! strip_file "$SM_WCP_CONF" xml; then
        _RH_RC=1
    fi
    if ! strip_file "$MMUI_XML" xml; then
        _RH_RC=1
    fi
    return $_RH_RC
}

# --------------------------------------------------------------------------
# Summary: Persistent Service Activation (Hook Injection & Recovery Suppression)
# --------------------------------------------------------------------------
do_enable() {
    acquire_lock
    autox_log "$ID" "[START] Enabling $TITLE"
    if ! check_firmware; then
        release_lock
        return 1
    fi
    cmu_remount_rw
    mazda_watchdog_disable

    if ! remove_hooks; then
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    if ! patch_sm "$SM_CONF"; then
        enable_abort
        return 1
    fi
    if [ -f "$SM_WCP_CONF" ]; then
        if ! patch_sm "$SM_WCP_CONF"; then
            enable_abort
            return 1
        fi
    else
        autox_log "$ID" "[SKIP] $SM_WCP_CONF not present on this CMU."
    fi
    if ! insert_file "$MMUI_XML" xml 1 \
        'uiaid="10" name="pandora"' '' '' 1; then
        enable_abort
        return 1
    fi
    if ! insert_file "$GUIRES_JS" js 1 \
        '"pandora": true' 'true' 'false' 1; then
        enable_abort
        return 1
    fi

    # SM-managed services (reset_board="yes") are never killed live; autorun="no" takes effect on reboot.
    [ "$1" = "--staged" ] && autox_log "$ID" "[STAGED] Hooks staged for next boot."

    if ! touch "$FLAG" 2>/dev/null; then
        autox_log "$ID" "[ERROR] Cannot create $FLAG (run install first)."
        enable_abort
        return 1
    fi
    autox_log "$ID" "[HOOK] Pandora UIA 10, blm_ira_pandora and irs_server disabled."

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    if [ "$REBOOT_REQUIRED" = "true" ]; then
        autox_log "$ID" "[REBOOT] $TITLE requires CMU reboot to take effect."
        echo "SUCCESS: $TITLE enabled. [REBOOT_REQUIRED=true]"
    else
        echo "SUCCESS: $TITLE enabled."
    fi
}

# --------------------------------------------------------------------------
# Summary: Service Deactivation (Process Termination & Hook Deletion)
# --------------------------------------------------------------------------
do_disable() {
    acquire_lock
    autox_log "$ID" "[START] Disabling $TITLE"
    cmu_remount_rw
    mazda_watchdog_disable

    if ! remove_hooks; then
        sync
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        autox_log "$ID" "[ERROR] Failed restoring OEM Pandora configuration."
        return 1
    fi
    rm -f "$FLAG" 2>/dev/null

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: $TITLE disabled."
}

# --------------------------------------------------------------------------
# Summary: Total Plugin Purge (Hook Removal, Process Kill & Target Script Deletion)
# --------------------------------------------------------------------------
do_uninstall() {
    acquire_lock
    autox_log "$ID" "[START] Uninstalling $TITLE"
    cmu_remount_rw
    mazda_watchdog_disable

    if ! remove_hooks; then
        sync
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        autox_log "$ID" "[ERROR] Failed restoring OEM Pandora configuration; uninstall aborted."
        return 1
    fi

    rm -f "$FLAG" "$LOCK_FILE" "$PLUGIN_TARGET" 2>/dev/null

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: Plugin uninstalled."
}

# --------------------------------------------------------------------------
# Summary: Master CLI Action Router & Framework Dispatcher
# --------------------------------------------------------------------------
execute_plugin() {
    _ACTION="$1"
    case "$_ACTION" in
        "version"|"--version")
            echo "$VERSION"
            ;;
        "install"|"--install")
            do_install
            ;;
        "reinstall")
            do_reinstall "$2"
            ;;
        "toggle"|"--toggle")
            if [ -f "$FLAG" ]; then
                execute_plugin "disable"
            else
                execute_plugin "enable"
            fi
            ;;
        "enable"|"--enable")
            do_enable "$2"
            ;;
        "disable"|"--disable")
            do_disable
            ;;
        "shutdown")
            autox_log "$ID" "[SHUTDOWN] No plugin-owned processes to stop (SM-managed services untouched)."
            ;;
        "uninstall")
            do_uninstall
            ;;
        "status"|"--status"|"-s")
            get_status
            ;;
        "raw"|"--raw")
            get_status
            ;;
        "meta"|"--meta")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"title\":\"$TITLE\",\"subtitle\":\"$SUBTITLE\",\"author\":\"$AUTHOR\",\"category\":\"$CATEGORY\",\"order\":$ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":$SHOW_IN_GUI,\"install_state\":\"$INSTALL_STATE\",\"reboot_required\":$REBOOT_REQUIRED,\"long_press\":$LONG_PRESS}"
            ;;
        "json"|"--json")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"usb\":\"${USB_ROOT:-NONE}\"}"
            ;;
        "help"|"--help"|"-h"|*)
            autox_log "$ID" "Started do_help/usage event"
            echo "$TITLE v$VERSION"
            echo "Usage: autox_${ID}.sh [install|reinstall|toggle|enable|disable|shutdown|uninstall|status|raw|meta|json|help]"
            ;;
    esac
}

execute_plugin "$@"
