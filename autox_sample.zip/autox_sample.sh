#!/bin/sh
# ==============================================================================
# AutoX Application Runner Framework Plugin - Standard Target Module
# ==============================================================================
# Target Platform: Mazda Connect CMU FW 74.00.324 ONLY
# Architecture: ARMv7 / i.MX6 Dual/Quad SoC
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

TITLE="The plugin title here"
SUBTITLE="Sample"
ID="sample"
NAME="SAMPLE"
AUTHOR="Name of the author here"
CATEGORY="tweak"
ORDER=10
SHOW_IN_GUI="true"
VERSION="v0.11"
INSTALL_STATE="disabled"
REBOOT_REQUIRED="true"

AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"

FLAG="$ENABLED_DIR/${ID}_enabled"
LOCK_FILE="/tmp/autox_${ID}.lock"
PLUGIN_TARGET="$PLUGINS_DIR/autox_${ID}.sh"
SCRIPT_PATH=$(readlink -f "$0" 2>/dev/null || echo "$0")

. /tmp/mnt/data_persist/autox/lib/autox_lib.sh

# --------------------------------------------------------------------------
# Summary: Runtime Execution State Query (Returns "ENABLED" | "DISABLED")
# --------------------------------------------------------------------------
get_status() {
    if [ -f "$FLAG" ]; then echo "ENABLED"; else echo "DISABLED"; fi
}

# --------------------------------------------------------------------------
# Summary: First-Run Deployment Routine (NAND Staging & Permission Hardening)
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    autox_log "$ID" "[START] $TITLE $VERSION Installation Initiated"
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR" 2>/dev/null
    autox_log "$ID" "[COMPLETED] $TITLE $VERSION successfully deployed."
    release_lock
}

# --------------------------------------------------------------------------
# Summary: In-Place Upgrade Handler (Version Matching & Safe State Preservation)
# --------------------------------------------------------------------------
do_reinstall() {
    FORCE=0
    [ "$1" = "--force" ] || [ "$2" = "--force" ] && FORCE=1
    
    CUR_VER="0"
    [ -f "$PLUGIN_TARGET" ] && CUR_VER=$("/bin/sh" "$PLUGIN_TARGET" version 2>/dev/null || echo "0")
    if [ "$CUR_VER" = "$VERSION" ] && [ $FORCE -eq 0 ]; then
        autox_log "$ID" "[SKIP] $ID already at $VERSION. Skipping in-place rewrite."
        return 0
    fi
    
    WAS_ENABLED=0; [ -f "$FLAG" ] && WAS_ENABLED=1
    [ -f "$PLUGIN_TARGET" ] && /bin/sh "$PLUGIN_TARGET" uninstall 2>/dev/null
    cp -f "$SCRIPT_PATH" "$PLUGIN_TARGET"
    chmod 755 "$PLUGIN_TARGET" 2>/dev/null
    
    if [ $WAS_ENABLED -eq 1 ]; then
        /bin/sh "$PLUGIN_TARGET" enable --staged
    fi
    autox_log "$ID" "[REINSTALL] Successfully updated $ID to $VERSION."
}

# --------------------------------------------------------------------------
# Summary: Total Plugin Purge (Hook Removal, Process Kill & Target Script Deletion)
# --------------------------------------------------------------------------
do_uninstall() {
    acquire_lock
    autox_log "$ID" "[START] Uninstalling $TITLE"
    cmu_remount_rw
    mazda_watchdog_disable

    SYS_APP="/jci/gui/apps/system/js/systemApp.js"
    if [ -f "$SYS_APP" ]; then
        sed -i '/\/\/ === AutoX disclaimer Boot Hook ===/,/\/\/ === AutoX disclaimer Boot Hook End/d' "$SYS_APP" 2>/dev/null
        autox_log "$ID" "[HOOK] Surgically stripped disclaimer hook from systemApp.js"
    fi

    rm -f "$FLAG" "$PLUGIN_TARGET" 2>/dev/null

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: Plugin uninstalled."
}

# --------------------------------------------------------------------------
# Summary: Master CLI Action Router & Framework Dispatcher
# --------------------------------------------------------------------------
execute_plugin() {
    _ACTION="$1"
    case "$_ACTION" in
        "version"|"--version")
            echo "$VERSION"
            ;;
        "install"|"--install")
            do_install
            ;;
        "reinstall")
            do_reinstall "$2"
            ;;
        "toggle"|"--toggle")
            if [ -f "$FLAG" ]; then
                execute_plugin "disable"
            else
                execute_plugin "enable"
            fi
            ;;
        "enable"|"--enable")
            acquire_lock
            autox_log "$ID" "[START] Enabling $TITLE"
            cmu_remount_rw
            mazda_watchdog_disable
            
            touch "$FLAG" 2>/dev/null
            
            SYS_APP="/jci/gui/apps/system/js/systemApp.js"
            if [ -f "$SYS_APP" ]; then
                sed -i '/\/\/ === AutoX disclaimer Boot Hook ===/,/\/\/ === AutoX disclaimer Boot Hook End/d' "$SYS_APP" 2>/dev/null
                cat << 'EOF' >> "$SYS_APP"
// === AutoX disclaimer Boot Hook ===
systemApp.prototype._displayedDisclaimer = function() {
    framework.sendEventToMmui("system", "DisposeIntroVideo");
    framework.sendEventToMmui(this.uiaId, "Timeout");
};
// === AutoX disclaimer Boot Hook End ===
EOF
                autox_log "$ID" "[HOOK] Injected disclaimer bypass hook into systemApp.js"
            fi
            
            sync
            mazda_watchdog_enable
            cmu_remount_ro
            release_lock
            if [ "$REBOOT_REQUIRED" = "true" ]; then
                autox_log "$ID" "[REBOOT] $TITLE requires CMU reboot to take effect."
                echo "SUCCESS: $TITLE enabled. [REBOOT_REQUIRED=true]"
            else
                echo "SUCCESS: $TITLE enabled."
            fi
            ;;
        "disable"|"--disable")
            acquire_lock
            autox_log "$ID" "[START] Disabling $TITLE"
            cmu_remount_rw
            mazda_watchdog_disable
            
            SYS_APP="/jci/gui/apps/system/js/systemApp.js"
            if [ -f "$SYS_APP" ]; then
                sed -i '/\/\/ === AutoX disclaimer Boot Hook ===/,/\/\/ === AutoX disclaimer Boot Hook End/d' "$SYS_APP" 2>/dev/null
                autox_log "$ID" "[HOOK] Surgically stripped disclaimer hook from systemApp.js"
            fi
            
            rm -f "$FLAG" 2>/dev/null
            
            sync
            mazda_watchdog_enable
            cmu_remount_ro
            release_lock
            echo "SUCCESS: $TITLE disabled."
            ;;
        "shutdown")
            autox_log "$ID" "[SHUTDOWN] No active daemon processes to stop."
            ;;
        "uninstall")
            do_uninstall
            ;;
        "status"|"--status"|"-s")
            get_status
            ;;
        "raw"|"--raw")
            get_status
            ;;
        "meta"|"--meta")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"title\":\"$TITLE\",\"subtitle\":\"$SUBTITLE\",\"author\":\"$AUTHOR\",\"category\":\"$CATEGORY\",\"order\":$ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":$SHOW_IN_GUI,\"install_state\":\"$INSTALL_STATE\",\"reboot_required\":${REBOOT_REQUIRED:-false}}"
            ;;
        "json"|"--json")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"usb\":\"${USB_ROOT:-NONE}\"}"
            ;;
        "help"|"--help"|"-h"|*)
            autox_log "$ID" "Started do_help/usage event"
            echo "$TITLE $VERSION"
            echo "Usage: autox_${ID}.sh [install|reinstall|toggle|enable|disable|shutdown|uninstall|status|raw|meta|json|help]"
            ;;
    esac
}

execute_plugin "$@"
