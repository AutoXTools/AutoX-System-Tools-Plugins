// AutoX Plugin UI: Wi-Fi Configuration Modal & Inline Touch Keyboard
// Target Platform: Mazda Connect Opera 12 Browser (FW 74.00.324 - Strict ES5)
window.AUTOX_PLUGIN_UI = window.AUTOX_PLUGIN_UI || {};
window.AUTOX_PLUGIN_INIT = window.AUTOX_PLUGIN_INIT || {};
window.AUTOX_PLUGIN_CLOSE = window.AUTOX_PLUGIN_CLOSE || {};

window.AUTOX_PLUGIN_UI['wifi'] =
  '<div class="card-header">' +
    '<div class="card-title">' +
      '<table cellspacing="0" cellpadding="0" style="border:none;margin:0;padding:0;display:inline-table;vertical-align:middle;">' +
        '<tr>' +
          '<td style="vertical-align:middle;padding-right:8px;">' +
            '<svg class="autox-logo-brand" viewBox="0 0 98 30" width="90" height="27">' +
              '<path fill="#FFFFFF" d="M 11,3.5 L 15.8,3.5 L 22,27.5 L 16.6,27.5 L 15,21 L 7,21 L 5.4,27.5 L 0,27.5 Z M 11,8.5 L 8.1,16.5 L 13.9,16.5 Z M 24,9.5 L 29.4,9.5 L 29.4,21.5 C 29.4,23 30.5,23.5 31.8,23.5 C 33.1,23.5 34.2,23 34.2,21.5 L 34.2,9.5 L 39.5,9.5 L 39.5,27.5 L 34.4,27.5 L 34.4,25.2 C 33.2,26.8 30.8,27.5 28.5,27.5 C 25.5,27.5 24,25.6 24,22.4 Z M 43,4.5 L 48.2,4.5 L 48.2,9.5 L 52,9.5 L 52,13.8 L 48.2,13.8 L 48.2,21.2 C 48.2,22.6 49,23.2 50.4,23.2 L 52,23.2 L 52,27.5 C 49.5,27.5 47,27.5 45,26.4 C 43,25.2 43,23 43,20.8 L 43,13.8 L 40,13.8 L 40,9.5 L 43,9.5 Z M 61,9.5 C 66.2,9.5 70,13.3 70,18.5 C 70,23.7 66.2,27.5 61,27.5 C 55.8,27.5 52,23.7 52,18.5 C 52,13.3 55.8,9.5 61,9.5 Z M 61,14.2 C 58.5,14.2 57.5,16 57.5,18.5 C 57.5,21 58.5,22.8 61,22.8 C 63.5,22.8 64.5,21 64.5,18.5 C 64.5,16 63.5,14.2 61,14.2 Z M 73,4 L 79.8,4 L 84.5,11 L 89.2,4 L 96,4 L 88.5,15.5 L 96.5,27.5 L 89.7,27.5 L 84.5,19.8 L 79.3,27.5 L 72.5,27.5 L 80.5,15.5 Z"/>' +
            '</svg>' +
          '</td>' +
          '<td style="vertical-align:middle;line-height:1.1;">' +
            '<div class="autox-brand-sub">Wi-Fi Configuration <span class="plugin-version-tag" data-plugin-ver="wifi" style="color:#F59E0B;font-size:11px;font-weight:bold;margin-left:5px;"></span></div>' +
            '<div id="wifi-modal-status-line" style="font-size:11px;font-weight:bold;color:#38BDF8;margin-top:2px;">Loading Wi-Fi configuration...</div>' +
          '</td>' +
        '</tr>' +
      '</table>' +
    '</div>' +
    '<div style="float:right;padding-right:36px;height:30px;line-height:30px;">' +
      '<button type="button" id="wifi-btn-scan" class="btn-drive-refresh" onclick="window.wifiUiScan()" style="margin-right:4px;"><span>Scan Networks</span></button>' +
    '</div>' +
    '<button type="button" class="close-btn" onclick="closeDynamicPluginModal()" title="Close Window">X</button>' +
    '<div style="clear:both;height:6px;font-size:1px;line-height:1px;"></div>' +
    '<div class="header-divider-line"></div>' +
  '</div>' +

  '<div id="wifi-main-layout" style="margin-top:6px;">' +
    '<table cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse;">' +
      '<tr>' +
        '<td style="width:45%;vertical-align:top;padding-right:8px;">' +
          '<div style="background:#0E0F14;border:1px solid #262A36;border-radius:6px;padding:7px;">' +
            '<div style="font-size:10.5px;font-weight:bold;color:#9CA3AF;text-transform:uppercase;margin-bottom:5px;">Available Wi-Fi Networks</div>' +
            '<div id="wifi-scan-list" style="height:282px;overflow-y:auto;background:#08090C;border:1px solid #1C202B;border-radius:4px;padding:4px;">' +
              '<div style="color:#6B7280;font-size:11.5px;padding:18px 8px;text-align:center;">Tap <strong>Scan Networks</strong> to search nearby Wi-Fi hotspots.</div>' +
            '</div>' +
          '</div>' +
        '</td>' +
        '<td style="width:55%;vertical-align:top;">' +
          '<div style="background:#0E0F14;border:1px solid #262A36;border-radius:6px;padding:8px 10px;">' +
            '<div style="font-size:10.5px;font-weight:bold;color:#9CA3AF;text-transform:uppercase;margin-bottom:5px;">Connection Mode</div>' +
            '<div style="margin-bottom:8px;">' +
              '<button type="button" id="wifi-mode-auto" onclick="window.wifiUiSetMode(\'auto\')" style="width:32%;height:28px;font-size:11px;font-weight:bold;border-radius:4px;border:1px solid #38BDF8;background:#163047;color:#FFFFFF;cursor:pointer;margin-right:2%;">Auto</button>' +
              '<button type="button" id="wifi-mode-client" onclick="window.wifiUiSetMode(\'client\')" style="width:32%;height:28px;font-size:11px;font-weight:bold;border-radius:4px;border:1px solid #33394A;background:#1A1D26;color:#9CA3AF;cursor:pointer;margin-right:2%;">Client</button>' +
              '<button type="button" id="wifi-mode-ap" onclick="window.wifiUiSetMode(\'ap\')" style="width:32%;height:28px;font-size:11px;font-weight:bold;border-radius:4px;border:1px solid #33394A;background:#1A1D26;color:#9CA3AF;cursor:pointer;">AP Hotspot</button>' +
            '</div>' +

            '<div style="font-size:10.5px;font-weight:bold;color:#9CA3AF;text-transform:uppercase;margin-bottom:3px;">Network Name (SSID)</div>' +
            '<div style="margin-bottom:7px;">' +
              '<input id="wifi-input-ssid" type="text" readonly="readonly" onclick="window.wifiUiOpenKeyboard(\'ssid\')" placeholder="Select from list or tap to type" style="width:76%;height:30px;padding:0 8px;background:#08090C;color:#FFFFFF;border:1px solid #33394A;border-radius:4px;font-size:12.5px;box-sizing:border-box;vertical-align:middle;" />' +
              '<button type="button" onclick="window.wifiUiOpenKeyboard(\'ssid\')" style="width:22%;height:30px;margin-left:2%;background:#1E2432;color:#38BDF8;border:1px solid #334155;border-radius:4px;font-size:11px;font-weight:bold;cursor:pointer;vertical-align:middle;">Type</button>' +
            '</div>' +

            '<div style="font-size:10.5px;font-weight:bold;color:#9CA3AF;text-transform:uppercase;margin-bottom:3px;">Security</div>' +
            '<div style="margin-bottom:7px;">' +
              '<button type="button" id="wifi-sec-wpa" onclick="window.wifiUiSetSecurity(\'WPA-PSK\')" style="width:49%;height:27px;font-size:11px;font-weight:bold;border-radius:4px;border:1px solid #00FF66;background:#113122;color:#00FF66;cursor:pointer;margin-right:2%;">WPA / WPA2-PSK</button>' +
              '<button type="button" id="wifi-sec-open" onclick="window.wifiUiSetSecurity(\'NONE\')" style="width:49%;height:27px;font-size:11px;font-weight:bold;border-radius:4px;border:1px solid #33394A;background:#1A1D26;color:#9CA3AF;cursor:pointer;">Open (No Password)</button>' +
            '</div>' +

            '<div id="wifi-psk-row" style="margin-bottom:8px;">' +
              '<div style="font-size:10.5px;font-weight:bold;color:#9CA3AF;text-transform:uppercase;margin-bottom:3px;">Wi-Fi Password</div>' +
              '<input id="wifi-input-psk" type="password" readonly="readonly" onclick="window.wifiUiOpenKeyboard(\'psk\')" placeholder="Tap to enter password" style="width:57%;height:30px;padding:0 8px;background:#08090C;color:#FFFFFF;border:1px solid #33394A;border-radius:4px;font-size:12.5px;box-sizing:border-box;vertical-align:middle;" />' +
              '<button type="button" id="wifi-btn-show-psk" onclick="window.wifiUiToggleMask()" style="width:20%;height:30px;margin-left:1.5%;background:#1E2432;color:#CBD5E1;border:1px solid #334155;border-radius:4px;font-size:10.5px;font-weight:bold;cursor:pointer;vertical-align:middle;">Show</button>' +
              '<button type="button" onclick="window.wifiUiOpenKeyboard(\'psk\')" style="width:20%;height:30px;margin-left:1.5%;background:#1E2432;color:#38BDF8;border:1px solid #334155;border-radius:4px;font-size:11px;font-weight:bold;cursor:pointer;vertical-align:middle;">Type</button>' +
            '</div>' +

            '<div id="wifi-ap-note" style="display:none;background:#121722;border:1px solid #273449;border-radius:4px;padding:6px 8px;margin-bottom:8px;font-size:11px;color:#93C5FD;">' +
              'AP Hotspot broadcasts <strong id="wifi-ap-ssid-label">Mazda-AutoX</strong> at <strong>192.168.53.1</strong>.' +
            '</div>' +

            '<div id="wifi-feedback-box" style="min-height:18px;font-size:11px;color:#A3ADC0;margin-bottom:8px;">Ready.</div>' +

            '<div>' +
              '<button type="button" id="wifi-btn-save-connect" onclick="window.wifiUiSave(true)" style="width:54%;height:34px;background:#0F5132;color:#00FF66;border:1px solid #00FF66;border-radius:5px;font-size:12px;font-weight:bold;cursor:pointer;margin-right:2%;">Save &amp; Connect</button>' +
              '<button type="button" id="wifi-btn-save-only" onclick="window.wifiUiSave(false)" style="width:26%;height:34px;background:#1E2432;color:#E2E8F0;border:1px solid #475569;border-radius:5px;font-size:11.5px;font-weight:bold;cursor:pointer;margin-right:2%;">Save Only</button>' +
              '<button type="button" onclick="closeDynamicPluginModal()" style="width:16%;height:34px;background:#1C1D24;color:#9CA3AF;border:1px solid #3F3F46;border-radius:5px;font-size:11.5px;font-weight:bold;cursor:pointer;">Close</button>' +
            '</div>' +
          '</div>' +
        '</td>' +
      '</tr>' +
    '</table>' +
  '</div>' +

  '<div id="wifi-kb-panel" style="display:none;margin-top:6px;background:#0B0D12;border:1px solid #38BDF8;border-radius:6px;padding:8px;">' +
    '<div style="margin-bottom:6px;">' +
      '<span id="wifi-kb-label" style="font-size:11px;font-weight:bold;color:#38BDF8;text-transform:uppercase;">Editing Field</span>' +
      '<input id="wifi-kb-preview" type="text" readonly="readonly" style="width:74%;height:28px;margin-left:8px;padding:0 8px;background:#050608;color:#FFFFFF;border:1px solid #334155;border-radius:4px;font-size:13px;box-sizing:border-box;vertical-align:middle;" />' +
      '<button type="button" onclick="window.wifiUiKbClear()" style="float:right;height:28px;padding:0 10px;background:#2C1618;color:#FCA5A5;border:1px solid #7F1D1D;border-radius:4px;font-size:11px;font-weight:bold;cursor:pointer;">Clear</button>' +
      '<div style="clear:both;"></div>' +
    '</div>' +
    '<div id="wifi-kb-keys"></div>' +
  '</div>';

window.AUTOX_PLUGIN_INIT['wifi'] = function() {
  window._wifiUiState = {
    mode: 'auto',
    security: 'WPA-PSK',
    showPsk: false,
    kbTarget: 'ssid',
    kbShift: false,
    kbSymbols: false,
    kbBuffer: '',
    apWasPaused: false,
    savedConnected: false,
    busy: false
  };

  function setStatusLine(msg, color) {
    var el = document.getElementById('wifi-modal-status-line');
    if (el) {
      el.innerHTML = msg;
      if (color) el.style.color = color;
    }
  }

  function setFeedback(msg, color) {
    var el = document.getElementById('wifi-feedback-box');
    if (el) {
      el.innerHTML = msg;
      el.style.color = color || '#A3ADC0';
    }
  }

  function escapeText(str) {
    return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function parseJsonSafeLocal(txt) {
    try {
      if (typeof window.parseJsonSafe === 'function') return window.parseJsonSafe(txt);
      return JSON.parse(txt);
    } catch (e) { return null; }
  }

  window.wifiUiSetMode = function(mode) {
    window._wifiUiState.mode = mode;
    var modes = ['auto', 'client', 'ap'];
    for (var i = 0; i < modes.length; i++) {
      var btn = document.getElementById('wifi-mode-' + modes[i]);
      if (!btn) continue;
      if (modes[i] === mode) {
        btn.style.borderColor = '#38BDF8';
        btn.style.background = '#163047';
        btn.style.color = '#FFFFFF';
      } else {
        btn.style.borderColor = '#33394A';
        btn.style.background = '#1A1D26';
        btn.style.color = '#9CA3AF';
      }
    }
    var apNote = document.getElementById('wifi-ap-note');
    if (apNote) {
      apNote.style.display = (mode === 'ap') ? 'block' : 'none';
    }
  };

  window.wifiUiSetSecurity = function(sec) {
    var isOpen = (sec === 'NONE' || sec === 'OPEN');
    window._wifiUiState.security = isOpen ? 'NONE' : 'WPA-PSK';
    var bWpa = document.getElementById('wifi-sec-wpa');
    var bOpen = document.getElementById('wifi-sec-open');
    var pskRow = document.getElementById('wifi-psk-row');
    if (bWpa && bOpen) {
      if (!isOpen) {
        bWpa.style.borderColor = '#00FF66'; bWpa.style.background = '#113122'; bWpa.style.color = '#00FF66';
        bOpen.style.borderColor = '#33394A'; bOpen.style.background = '#1A1D26'; bOpen.style.color = '#9CA3AF';
      } else {
        bOpen.style.borderColor = '#F59E0B'; bOpen.style.background = '#332611'; bOpen.style.color = '#FACC15';
        bWpa.style.borderColor = '#33394A'; bWpa.style.background = '#1A1D26'; bWpa.style.color = '#9CA3AF';
      }
    }
    if (pskRow) {
      pskRow.style.display = isOpen ? 'none' : 'block';
    }
  };

  window.wifiUiToggleMask = function() {
    var st = window._wifiUiState;
    st.showPsk = !st.showPsk;
    var pskInput = document.getElementById('wifi-input-psk');
    var btn = document.getElementById('wifi-btn-show-psk');
    if (pskInput) {
      try { pskInput.type = st.showPsk ? 'text' : 'password'; } catch (e) {}
    }
    if (btn) btn.innerHTML = st.showPsk ? 'Hide' : 'Show';
  };

  window.wifiUiSelectNetwork = function(idx) {
    var nets = window._wifiUiNetworks || [];
    var net = nets[idx];
    if (!net) return;
    var ssidEl = document.getElementById('wifi-input-ssid');
    if (ssidEl) ssidEl.value = net.ssid || '';
    var sec = String(net.security || 'WPA-PSK').toUpperCase();
    window.wifiUiSetSecurity((sec === 'OPEN' || sec === 'NONE') ? 'NONE' : 'WPA-PSK');
    if (window._wifiUiState.mode === 'ap') {
      window.wifiUiSetMode('auto');
    }
    setFeedback('Selected "' + escapeText(net.ssid) + '" (' + escapeText(sec) + ').', '#38BDF8');
  };

  function renderKeyboard() {
    var st = window._wifiUiState;
    var container = document.getElementById('wifi-kb-keys');
    var preview = document.getElementById('wifi-kb-preview');
    var lbl = document.getElementById('wifi-kb-label');
    if (!container) return;
    if (preview) {
      try { preview.type = (st.kbTarget === 'psk' && !st.showPsk) ? 'password' : 'text'; } catch (e) {}
      preview.value = st.kbBuffer;
    }
    if (lbl) lbl.innerHTML = (st.kbTarget === 'ssid') ? 'Enter Network SSID' : 'Enter Wi-Fi Password';

    var rows;
    if (st.kbSymbols) {
      rows = [
        ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')'],
        ['-', '_', '=', '+', '[', ']', '/', '?', '.', ',']
      ];
    } else if (st.kbShift) {
      rows = [
        ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
        ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', '-'],
        ['Z', 'X', 'C', 'V', 'B', 'N', 'M', '_', '.', '@']
      ];
    } else {
      rows = [
        ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
        ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', '-'],
        ['z', 'x', 'c', 'v', 'b', 'n', 'm', '_', '.', '@']
      ];
    }

    var h = '';
    for (var r = 0; r < rows.length; r++) {
      h += '<div style="margin-bottom:4px;text-align:center;">';
      for (var c = 0; c < rows[r].length; c++) {
        var ch = rows[r][c];
        h += '<button type="button" onclick="window.wifiUiKbKey(' + c + ',' + r + ')" style="width:9%;margin:0 0.4%;height:34px;background:#1A1F2B;color:#FFFFFF;border:1px solid #334155;border-radius:4px;font-size:13px;font-weight:bold;cursor:pointer;">' + escapeText(ch) + '</button>';
      }
      h += '</div>';
    }
    h += '<div style="text-align:center;margin-top:4px;">';
    h += '<button type="button" onclick="window.wifiUiKbShift()" style="width:15%;margin:0 0.5%;height:34px;background:' + (st.kbShift ? '#163047' : '#1E2432') + ';color:#38BDF8;border:1px solid #38BDF8;border-radius:4px;font-size:11px;font-weight:bold;cursor:pointer;">' + (st.kbShift ? 'SHIFT ON' : 'Shift') + '</button>';
    h += '<button type="button" onclick="window.wifiUiKbSym()" style="width:14%;margin:0 0.5%;height:34px;background:' + (st.kbSymbols ? '#163047' : '#1E2432') + ';color:#FACC15;border:1px solid #F59E0B;border-radius:4px;font-size:11px;font-weight:bold;cursor:pointer;">' + (st.kbSymbols ? 'ABC' : '!@#') + '</button>';
    h += '<button type="button" onclick="window.wifiUiKbSpace()" style="width:28%;margin:0 0.5%;height:34px;background:#1A1F2B;color:#CBD5E1;border:1px solid #334155;border-radius:4px;font-size:11px;font-weight:bold;cursor:pointer;">Space</button>';
    h += '<button type="button" onclick="window.wifiUiKbBksp()" style="width:17%;margin:0 0.5%;height:34px;background:#2C1618;color:#FCA5A5;border:1px solid #7F1D1D;border-radius:4px;font-size:11px;font-weight:bold;cursor:pointer;">Bksp</button>';
    h += '<button type="button" onclick="window.wifiUiKbDone()" style="width:18%;margin:0 0.5%;height:34px;background:#0F5132;color:#00FF66;border:1px solid #00FF66;border-radius:4px;font-size:12px;font-weight:bold;cursor:pointer;">Done</button>';
    h += '</div>';
    window._wifiUiKbRows = rows;
    container.innerHTML = h;
  }

  window.wifiUiOpenKeyboard = function(target) {
    var st = window._wifiUiState;
    st.kbTarget = target;
    var src = document.getElementById(target === 'ssid' ? 'wifi-input-ssid' : 'wifi-input-psk');
    st.kbBuffer = src ? String(src.value || '') : '';
    var mainEl = document.getElementById('wifi-main-layout');
    var kbEl = document.getElementById('wifi-kb-panel');
    if (mainEl) mainEl.style.display = 'none';
    if (kbEl) kbEl.style.display = 'block';
    renderKeyboard();
  };

  window.wifiUiKbKey = function(c, r) {
    var rows = window._wifiUiKbRows || [];
    if (rows[r] && typeof rows[r][c] === 'string') {
      window._wifiUiState.kbBuffer += rows[r][c];
      renderKeyboard();
    }
  };
  window.wifiUiKbShift = function() {
    window._wifiUiState.kbSymbols = false;
    window._wifiUiState.kbShift = !window._wifiUiState.kbShift;
    renderKeyboard();
  };
  window.wifiUiKbSym = function() {
    window._wifiUiState.kbSymbols = !window._wifiUiState.kbSymbols;
    renderKeyboard();
  };
  window.wifiUiKbSpace = function() {
    window._wifiUiState.kbBuffer += ' ';
    renderKeyboard();
  };
  window.wifiUiKbBksp = function() {
    var b = window._wifiUiState.kbBuffer;
    window._wifiUiState.kbBuffer = b.length > 0 ? b.substring(0, b.length - 1) : '';
    renderKeyboard();
  };
  window.wifiUiKbClear = function() {
    window._wifiUiState.kbBuffer = '';
    renderKeyboard();
  };
  window.wifiUiKbDone = function() {
    var st = window._wifiUiState;
    var dst = document.getElementById(st.kbTarget === 'ssid' ? 'wifi-input-ssid' : 'wifi-input-psk');
    if (dst) dst.value = st.kbBuffer;
    var mainEl = document.getElementById('wifi-main-layout');
    var kbEl = document.getElementById('wifi-kb-panel');
    if (kbEl) kbEl.style.display = 'none';
    if (mainEl) mainEl.style.display = 'block';
  };

  window.wifiUiScan = function() {
    var listEl = document.getElementById('wifi-scan-list');
    var scanBtn = document.getElementById('wifi-btn-scan');
    if (scanBtn) scanBtn.disabled = true;
    if (listEl) listEl.innerHTML = '<div style="color:#38BDF8;font-size:12px;padding:24px 8px;text-align:center;">Scanning nearby Wi-Fi networks...</div>';
    setFeedback('Scanning wlan0 for nearby access points...', '#38BDF8');

    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'cgi-bin/plugins.cgi?action=scan&id=wifi&t=' + (new Date()).getTime(), true);
    xhr.onreadystatechange = function() {
      if (xhr.readyState !== 4) return;
      if (scanBtn) scanBtn.disabled = false;
      var data = parseJsonSafeLocal(xhr.responseText);
      if (xhr.status >= 200 && xhr.status < 300 && data && data.networks) {
        if (data.was_ap === true || data.was_ap === 'true') {
          window._wifiUiState.apWasPaused = true;
        }
        window._wifiUiNetworks = data.networks;
        if (!data.networks.length) {
          if (listEl) listEl.innerHTML = '<div style="color:#9CA3AF;font-size:11.5px;padding:18px 8px;text-align:center;">No networks found. Tap Scan Networks to retry.</div>';
          setFeedback('Scan finished: 0 networks found.', '#FACC15');
          return;
        }
        var out = '';
        for (var i = 0; i < data.networks.length; i++) {
          var n = data.networks[i];
          var secTxt = escapeText(n.security || 'WPA-PSK');
          var secColor = (secTxt === 'OPEN' || secTxt === 'NONE') ? '#FACC15' : '#00FF66';
          out += '<div onclick="window.wifiUiSelectNetwork(' + i + ')" style="padding:7px 8px;margin-bottom:4px;background:#141720;border:1px solid #282E3D;border-radius:4px;cursor:pointer;">' +
            '<div style="font-size:12.5px;font-weight:bold;color:#FFFFFF;overflow:hidden;">' + escapeText(n.ssid) + '</div>' +
            '<div style="font-size:10px;color:#9CA3AF;margin-top:2px;">Signal: ' + escapeText(n.signal || '--') + ' &bull; <span style="color:' + secColor + ';font-weight:bold;">' + secTxt + '</span></div>' +
          '</div>';
        }
        if (listEl) listEl.innerHTML = out;
        setFeedback('Found ' + data.networks.length + ' Wi-Fi network(s). Tap one to select.', '#00FF66');
      } else {
        if (listEl) listEl.innerHTML = '<div style="color:#F87171;font-size:11.5px;padding:18px 8px;text-align:center;">Wi-Fi scan failed.</div>';
        setFeedback('Scan failed (HTTP ' + xhr.status + ').', '#F87171');
      }
    };
    xhr.send(null);
  };

  window.wifiUiSave = function(connectNow) {
    var st = window._wifiUiState;
    if (st.busy) return;
    var ssidEl = document.getElementById('wifi-input-ssid');
    var pskEl = document.getElementById('wifi-input-psk');
    var ssidVal = ssidEl ? String(ssidEl.value || '') : '';
    var pskVal = pskEl ? String(pskEl.value || '') : '';

    if (st.mode !== 'ap' && (!ssidVal || ssidVal === 'YourSSID')) {
      setFeedback('Enter or select a valid Wi-Fi SSID first.', '#F87171');
      return;
    }

    st.busy = true;
    var btnConn = document.getElementById('wifi-btn-save-connect');
    var btnSave = document.getElementById('wifi-btn-save-only');
    if (btnConn) btnConn.disabled = true;
    if (btnSave) btnSave.disabled = true;
    setFeedback(connectNow ? 'Saving wifi.conf and connecting...' : 'Saving wifi.conf...', '#38BDF8');

    var payload =
      'wifi_mode=' + encodeURIComponent(st.mode) +
      '&client_ssid=' + encodeURIComponent(ssidVal) +
      '&client_psk=' + encodeURIComponent(pskVal) +
      '&client_security=' + encodeURIComponent(st.security) +
      '&connect=' + (connectNow ? 'true' : 'false');

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'cgi-bin/plugins.cgi?action=set_config&id=wifi&t=' + (new Date()).getTime(), true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
      if (xhr.readyState !== 4) return;
      st.busy = false;
      if (btnConn) btnConn.disabled = false;
      if (btnSave) btnSave.disabled = false;
      var res = parseJsonSafeLocal(xhr.responseText);
      if (xhr.status >= 200 && xhr.status < 300 && res && (res.saved === true || res.saved === 'true')) {
        st.savedConnected = !!connectNow;
        if (connectNow) {
          st.apWasPaused = false;
          setStatusLine('CONNECTING: ' + escapeText(ssidVal || st.mode.toUpperCase()), '#FACC15');
          setFeedback('Saved wifi.conf & connecting...', '#00FF66');
          if (typeof window.setStoredPluginStatus === 'function') window.setStoredPluginStatus('wifi', 'CONNECTING');
          if (typeof window.setPluginBusyUI === 'function') window.setPluginBusyUI('wifi', false);
          if (typeof window.pollWifiUntilSettled === 'function') window.pollWifiUntilSettled();
          if (typeof window.log === 'function') window.log('[Wi-Fi Config] Saved settings and initiated connection to ' + (ssidVal || st.mode));
          setTimeout(function() {
            if (typeof window.closeDynamicPluginModal === 'function') window.closeDynamicPluginModal();
          }, 500);
        } else {
          setFeedback('Configuration saved to /tmp/mnt/data_persist/autox/data/wifi.conf.', '#00FF66');
          if (typeof window.log === 'function') window.log('[Wi-Fi Config] Saved settings to wifi.conf.');
        }
      } else {
        setFeedback((res && res.message) ? escapeText(res.message) : 'Failed to save configuration.', '#F87171');
      }
    };
    xhr.send(payload);
  };

  window.AUTOX_PLUGIN_CLOSE['wifi'] = function() {
    var st = window._wifiUiState;
    if (st && st.apWasPaused && !st.savedConnected) {
      try {
        var rx = new XMLHttpRequest();
        rx.open('GET', 'cgi-bin/plugins.cgi?action=restore_ap&id=wifi&t=' + (new Date()).getTime(), true);
        rx.send(null);
      } catch (e) {}
    }
  };

  // Initial hydrate from current wifi.conf
  var xhr = new XMLHttpRequest();
  xhr.open('GET', 'cgi-bin/plugins.cgi?action=get_config&id=wifi&t=' + (new Date()).getTime(), true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState !== 4) return;
    var cfg = parseJsonSafeLocal(xhr.responseText);
    if (xhr.status >= 200 && xhr.status < 300 && cfg) {
      var mode = cfg.wifi_mode || 'auto';
      window.wifiUiSetMode(mode);
      window.wifiUiSetSecurity(cfg.client_security || 'WPA-PSK');
      var ssidEl = document.getElementById('wifi-input-ssid');
      var pskEl = document.getElementById('wifi-input-psk');
      var apEl = document.getElementById('wifi-ap-ssid-label');
      if (ssidEl) ssidEl.value = (cfg.client_ssid && cfg.client_ssid !== 'YourSSID') ? cfg.client_ssid : '';
      if (pskEl) pskEl.value = (cfg.client_psk && cfg.client_psk !== 'YourHomeWiFiPassword') ? cfg.client_psk : '';
      if (apEl && cfg.ap_ssid) apEl.innerHTML = escapeText(cfg.ap_ssid);
      var statTxt = cfg.status || 'DISABLED';
      if (statTxt === 'ENABLED' && cfg.ip && cfg.ip !== 'none') {
        setStatusLine('ONLINE (' + escapeText(cfg.ip) + ')', '#00FF66');
      } else {
        setStatusLine('STATUS: ' + escapeText(statTxt) + ' | MODE: ' + escapeText(mode.toUpperCase()), statTxt === 'ENABLED' ? '#00FF66' : '#9CA3AF');
      }
    } else {
      setStatusLine('Unable to read wifi.conf', '#F87171');
    }
  };
  xhr.send(null);
};
