// AutoX ES5 Web UI Controller for Remove Disclaimer (disclaimer)
// Target Platform: Mazda Connect Opera 12 Browser (FW 74.00.324)

(function() {
  'use strict';

  var REBOOT_REQUIRED = true;

  function initPlugin() {
    var container = document.getElementById('plugin-disclaimer-card');
    if (!container) return;

    var btnToggle = container.querySelector('.btn-toggle');
    if (btnToggle) {
      btnToggle.addEventListener('click', function() {
        var isEnabled = btnToggle.getAttribute('data-enabled') === 'true';
        var action = isEnabled ? 'disable' : 'enable';
        
        if (window.AutoXBus) {
          window.AutoXBus.sendAction('disclaimer', action, function(err, response) {
            if (!err) {
              btnToggle.setAttribute('data-enabled', isEnabled ? 'false' : 'true');
              btnToggle.textContent = isEnabled ? 'Enable' : 'Active';
              if (action === 'enable' && (REBOOT_REQUIRED || (response && (response.reboot_required === true || response.reboot_required === 'true')))) {
                if (typeof window.showPluginRebootModal === 'function') {
                  window.showPluginRebootModal('disclaimer');
                }
              }
            }
          });
        }
      });
    }
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    initPlugin();
  } else {
    document.addEventListener('DOMContentLoaded', initPlugin);
  }
})();
