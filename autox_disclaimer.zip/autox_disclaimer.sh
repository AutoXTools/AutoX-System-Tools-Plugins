#!/bin/sh
# ==============================================================================
# AutoX Application Runner Framework Plugin - Standard Target Module
# ==============================================================================
# Target Platform: Mazda Connect CMU FW 74.00.324 ONLY
# Architecture: ARMv7 / i.MX6 Dual/Quad SoC
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

# --------------------------------------------------------------------------
# COMPILER BUILD DIRECTIVES (Non-Runtime Comments)
# --------------------------------------------------------------------------
# @directive hook_placement: custom
# @directive hook_placement_logic: Insert the hook before framework.registerAppLoaded("system", null, true); in /jci/gui/apps/system/js/systemApp.js

TITLE="Remove Disclaimer"
SUBTITLE="Improved system bootup experience"
ID="disclaimer"
NAME="DISCLAIMER"
AUTHOR="Autox"
CATEGORY="tweak"
ORDER=10
SHOW_IN_GUI="true"
VERSION="v0.12"
INSTALL_STATE="disabled"
REBOOT_REQUIRED="true"

AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"

FLAG="$ENABLED_DIR/${ID}_enabled"
LOCK_FILE="/tmp/autox_${ID}.lock"
PLUGIN_TARGET="$PLUGINS_DIR/autox_${ID}.sh"
SCRIPT_PATH=$(readlink -f "$0" 2>/dev/null)
[ -z "$SCRIPT_PATH" ] && SCRIPT_PATH="$0"

. /tmp/mnt/data_persist/autox/lib/autox_lib.sh
# --------------------------------------------------------------------------
# Summary: Runtime Execution State Query (Returns "ENABLED" | "DISABLED")
# --------------------------------------------------------------------------
get_status() {
    if [ -f "$FLAG" ]; then echo "ENABLED"; else echo "DISABLED"; fi
}
# --------------------------------------------------------------------------
# Summary: First-Run Deployment Routine (NAND Staging & Permission Hardening)
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    autox_log "$ID" "[START] $TITLE $VERSION Installation Initiated"
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR" 2>/dev/null
    autox_log "$ID" "[COMPLETED] $TITLE $VERSION successfully deployed."
    release_lock
}
# --------------------------------------------------------------------------
# Summary: In-Place Upgrade Handler (Version Matching & Safe State Preservation)
# --------------------------------------------------------------------------
do_reinstall() {
    FORCE=0
    [ "$1" = "--force" ] || [ "$2" = "--force" ] && FORCE=1

    if [ "$SCRIPT_PATH" = "$PLUGIN_TARGET" ]; then
        autox_log "$ID" "[ERROR] Cannot reinstall directly from installed target path $PLUGIN_TARGET."
        return 1
    fi

    CUR_VER="0"
    if [ -f "$PLUGIN_TARGET" ]; then
        CUR_VER=$("/bin/sh" "$PLUGIN_TARGET" version 2>/dev/null)
        [ -z "$CUR_VER" ] && CUR_VER="0"
    fi
    if [ "$CUR_VER" = "$VERSION" ] && [ $FORCE -eq 0 ]; then
        autox_log "$ID" "[SKIP] $ID already at $VERSION. Skipping in-place rewrite."
        return 0
    fi

    WAS_ENABLED=0
    [ -f "$FLAG" ] && WAS_ENABLED=1

    if [ -f "$PLUGIN_TARGET" ]; then
        if ! /bin/sh "$PLUGIN_TARGET" disable; then
            autox_log "$ID" "[ERROR] Failed disabling prior $ID hooks prior to upgrade."
            return 1
        fi
    fi

    if ! cmu_verify_persist_rw; then
        autox_log "$ID" "[ERROR] Persistent flash /tmp/mnt/data_persist is not writable."
        return 1
    fi

    if ! cp -f "$SCRIPT_PATH" "$PLUGIN_TARGET"; then
        autox_log "$ID" "[ERROR] Failed copying $SCRIPT_PATH to $PLUGIN_TARGET."
        return 1
    fi
    chmod 755 "$PLUGIN_TARGET" 2>/dev/null
    sync

    if ! /bin/sh "$PLUGIN_TARGET" install; then
        autox_log "$ID" "[ERROR] Failed installing upgraded $ID payload."
        return 1
    fi

    if [ $WAS_ENABLED -eq 1 ]; then
        if ! /bin/sh "$PLUGIN_TARGET" enable --staged; then
            autox_log "$ID" "[ERROR] Upgraded $ID failed staged re-enable."
            return 1
        fi
    fi
    autox_log "$ID" "[REINSTALL] Successfully updated $ID to $VERSION."
}
# --------------------------------------------------------------------------
# Summary: Remove Hooks Routine
# --------------------------------------------------------------------------
remove_hooks() {
    SYS_APP="/jci/gui/apps/system/js/systemApp.js"
    TMP_FILE="/tmp/autox_${ID}_rm.tmp"
    if [ -f "$SYS_APP" ]; then
        if grep -q '// === AutoX disclaimer Boot Hook ===' "$SYS_APP" 2>/dev/null && grep -q '// === AutoX disclaimer Boot Hook End ===' "$SYS_APP" 2>/dev/null; then
            sed '/\/\/ === AutoX disclaimer Boot Hook ===/,/\/\/ === AutoX disclaimer Boot Hook End ===/d' "$SYS_APP" > "$TMP_FILE"
            if [ $? -eq 0 ] && [ -s "$TMP_FILE" ]; then
                if cp -f "$TMP_FILE" "$SYS_APP"; then
                    rm -f "$TMP_FILE"
                    autox_log "$ID" "[HOOK] Surgically stripped disclaimer hook from systemApp.js"
                else
                    rm -f "$TMP_FILE"
                    autox_log "$ID" "[ERROR] Failed writing stripped systemApp.js to NAND"
                    return 1
                fi
            else
                rm -f "$TMP_FILE"
                autox_log "$ID" "[ERROR] Failed staging clean systemApp.js in /tmp"
                return 1
            fi
        fi
    fi
    return 0
}
# --------------------------------------------------------------------------
# Summary: Persistent Service Activation (Hook Injection & Recovery Suppression)
# --------------------------------------------------------------------------
do_enable() {
    acquire_lock
    autox_log "$ID" "[START] Enabling $TITLE"
    cmu_remount_rw
    mazda_watchdog_disable

    if ! remove_hooks; then
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    SYS_APP="/jci/gui/apps/system/js/systemApp.js"
    if [ ! -f "$SYS_APP" ]; then
        autox_log "$ID" "[ERROR] Missing target file $SYS_APP"
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    ANCHOR='framework.registerAppLoaded("system", null, true);'
    if ! grep -qF "$ANCHOR" "$SYS_APP" 2>/dev/null; then
        autox_log "$ID" "[ERROR] Custom hook anchor not found in $SYS_APP"
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    TMP_FILE="/tmp/autox_${ID}_ins.tmp"
    awk '
    BEGIN { inserted = 0 }
    !inserted && index($0, "framework.registerAppLoaded(\"system\", null, true);") > 0 {
        print "// === AutoX disclaimer Boot Hook ==="
        print "systemApp.prototype._displayedDisclaimer = function() {"
        print "    framework.sendEventToMmui(\"system\", \"DisposeIntroVideo\");"
        print "    framework.sendEventToMmui(this.uiaId, \"Timeout\");"
        print "};"
        print "// === AutoX disclaimer Boot Hook End ==="
        inserted = 1
    }
    { print }
    END { if (!inserted) exit 1 }
    ' "$SYS_APP" > "$TMP_FILE"

    if [ $? -ne 0 ] || [ ! -s "$TMP_FILE" ] || ! grep -q '// === AutoX disclaimer Boot Hook ===' "$TMP_FILE" 2>/dev/null; then
        rm -f "$TMP_FILE"
        autox_log "$ID" "[ERROR] Failed staging disclaimer bypass hook in /tmp"
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    if ! cp -f "$TMP_FILE" "$SYS_APP"; then
        rm -f "$TMP_FILE"
        autox_log "$ID" "[ERROR] Failed writing disclaimer bypass hook to $SYS_APP"
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi
    rm -f "$TMP_FILE"

    touch "$FLAG" 2>/dev/null
    autox_log "$ID" "[HOOK] Injected disclaimer bypass hook into systemApp.js"

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    if [ "$REBOOT_REQUIRED" = "true" ]; then
        autox_log "$ID" "[REBOOT] $TITLE requires CMU reboot to take effect."
        echo "SUCCESS: $TITLE enabled. [REBOOT_REQUIRED=true]"
    else
        echo "SUCCESS: $TITLE enabled."
    fi
}
# --------------------------------------------------------------------------
# Summary: Service Deactivation (Process Termination & Hook Deletion)
# --------------------------------------------------------------------------
do_disable() {
    acquire_lock
    autox_log "$ID" "[START] Disabling $TITLE"
    cmu_remount_rw
    mazda_watchdog_disable

    if ! remove_hooks; then
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi
    rm -f "$FLAG" 2>/dev/null

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: $TITLE disabled."
}
# --------------------------------------------------------------------------
# Summary: Total Plugin Purge (Hook Removal, Process Kill & Target Script Deletion)
# --------------------------------------------------------------------------
do_uninstall() {
    acquire_lock
    autox_log "$ID" "[START] Uninstalling $TITLE"
    cmu_remount_rw
    mazda_watchdog_disable

    if ! remove_hooks; then
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    rm -f "$FLAG" "$PLUGIN_TARGET" 2>/dev/null

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: Plugin uninstalled."
}
# --------------------------------------------------------------------------
# Summary: Master CLI Action Router & Framework Dispatcher
# --------------------------------------------------------------------------
execute_plugin() {
    _ACTION="$1"
    case "$_ACTION" in
        "version"|"--version")
            echo "$VERSION"
            ;;
        "install"|"--install")
            do_install
            ;;
        "reinstall")
            do_reinstall "$2"
            ;;
        "toggle"|"--toggle")
            if [ -f "$FLAG" ]; then
                execute_plugin "disable"
            else
                execute_plugin "enable"
            fi
            ;;
        "enable"|"--enable")
            do_enable "$2"
            ;;
        "disable"|"--disable")
            do_disable
            ;;
        "shutdown")
            autox_log "$ID" "[SHUTDOWN] No active daemon processes to stop."
            ;;
        "uninstall")
            do_uninstall
            ;;
        "status"|"--status"|"-s")
            get_status
            ;;
        "raw"|"--raw")
            get_status
            ;;
        "meta"|"--meta")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"title\":\"$TITLE\",\"subtitle\":\"$SUBTITLE\",\"author\":\"$AUTHOR\",\"category\":\"$CATEGORY\",\"order\":$ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":$SHOW_IN_GUI,\"install_state\":\"$INSTALL_STATE\",\"reboot_required\":${REBOOT_REQUIRED:-false}}"
            ;;
        "json"|"--json")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"usb\":\"${USB_ROOT:-NONE}\"}"
            ;;
        "help"|"--help"|"-h"|*)
            autox_log "$ID" "Started do_help/usage event"
            echo "$TITLE $VERSION"
            echo "Usage: autox_${ID}.sh [install|reinstall|toggle|enable|disable|shutdown|uninstall|status|raw|meta|json|help]"
            ;;
    esac
}

execute_plugin "$@"
