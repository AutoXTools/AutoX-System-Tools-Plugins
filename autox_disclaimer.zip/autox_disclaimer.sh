#!/bin/sh
# ==============================================================================
# AutoX Application Runner Framework Plugin - Standard Target Module
# ==============================================================================
# Target Platform: Mazda Connect CMU FW 74.00.324 ONLY
# Architecture: ARMv7 / i.MX6 Dual/Quad SoC
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

NAME="Remove_Disclaimer"
AUTHOR="AutoX"
ID="disclaimer"
TITLE="Remove Disclaimer"
SUBTITLE="Removes boot disclaimer for faster boot"
CATEGORY="tweak"
ORDER=10
SHOW_IN_GUI="true"
VERSION="v0.11"
INSTALL_STATE="disabled"

AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"

FLAG="$ENABLED_DIR/${ID}_enabled"
LOCK_FILE="/tmp/autox_${ID}.lock"
PLUGIN_TARGET="$PLUGINS_DIR/autox_${ID}.sh"
SCRIPT_PATH=$(readlink -f "$0" 2>/dev/null || echo "$0")

. /tmp/mnt/data_persist/autox/lib/autox_lib.sh

# --------------------------------------------------------------------------
# Summary: Runtime Execution State Query (Returns "ENABLED" | "DISABLED")
# --------------------------------------------------------------------------
get_status() {
    if [ -f "$FLAG" ]; then echo "ENABLED"; else echo "DISABLED"; fi
}

# --------------------------------------------------------------------------
# Summary: First-Run Deployment Routine (NAND Staging & Permission Hardening)
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    log_event "[START] $NAME $VERSION Installation Initiated"
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR" 2>/dev/null
    
    if [ -n "$AUTOX_USB_ROOT" ] && [ -f "$AUTOX_USB_ROOT/config/systemApp.js" ]; then
        cp -f "$AUTOX_USB_ROOT/config/systemApp.js" "$DATA_DIR/systemApp.js"
        chmod 644 "$DATA_DIR/systemApp.js"
        log_event "[FILE] Staged disclaimer systemApp.js asset to data dir"
    fi
    
    log_event "[COMPLETED] $NAME $VERSION successfully deployed."
    release_lock
}

# --------------------------------------------------------------------------
# Summary: In-Place Upgrade Handler (Version Matching & Safe State Preservation)
# --------------------------------------------------------------------------
do_reinstall() {
    FORCE=0
    [ "$1" = "--force" ] || [ "$2" = "--force" ] && FORCE=1
    
    CUR_VER="0"
    [ -f "$PLUGIN_TARGET" ] && CUR_VER=$("/bin/sh" "$PLUGIN_TARGET" version 2>/dev/null || echo "0")
    if [ "$CUR_VER" = "$VERSION" ] && [ $FORCE -eq 0 ]; then
        log_event "[SKIP] $ID already at $VERSION. Skipping in-place rewrite."
        return 0
    fi
    
    WAS_ENABLED=0; [ -f "$FLAG" ] && WAS_ENABLED=1
    [ -f "$PLUGIN_TARGET" ] && /bin/sh "$PLUGIN_TARGET" uninstall 2>/dev/null
    cp -f "$SCRIPT_PATH" "$PLUGIN_TARGET"
    chmod 755 "$PLUGIN_TARGET" 2>/dev/null
    
    if [ $WAS_ENABLED -eq 1 ]; then
        /bin/sh "$PLUGIN_TARGET" enable --staged
    fi
    log_event "[REINSTALL] Successfully updated $ID to $VERSION."
}

# --------------------------------------------------------------------------
# Summary: Plugin Teardown & NAND Cleanup Routine (Reverts Hooks & Cleans NAND)
# --------------------------------------------------------------------------
do_uninstall() {
    acquire_lock
    log_event "[START] Uninstalling $NAME"
    cmu_remount_rw
    mazda_watchdog_disable
    
    SYS_APP="/jci/gui/apps/system/js/systemApp.js"
    if [ -f "$SYS_APP" ]; then
        sed -i '/\/\/ === AutoX disclaimer Hook ===/,/\/\/ === AutoX disclaimer Hook End ===/d' "$SYS_APP" 2>/dev/null
        log_event "[HOOK] Removed disclaimer hook from systemApp.js"
    fi
    
    rm -f "$FLAG" "$DATA_DIR/systemApp.js" "$PLUGIN_TARGET" 2>/dev/null
    
    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: Plugin uninstalled."
}

# --------------------------------------------------------------------------
# Summary: Master CLI Action Router & Framework Dispatcher
# --------------------------------------------------------------------------
execute_plugin() {
    _ACTION="$1"
    case "$_ACTION" in
        "version"|"--version")
            echo "$VERSION"
            ;;
        "install"|"--install")
            do_install
            ;;
        "reinstall")
            do_reinstall "$2"
            ;;
        "enable"|"--enable")
            acquire_lock
            log_event "[START] Enabling $NAME"
            cmu_remount_rw
            mazda_watchdog_disable
            
            touch "$FLAG" 2>/dev/null
            
            SYS_APP="/jci/gui/apps/system/js/systemApp.js"
            if [ -f "$SYS_APP" ]; then
                sed -i '/\/\/ === AutoX disclaimer Hook ===/,/\/\/ === AutoX disclaimer Hook End ===/d' "$SYS_APP" 2>/dev/null
                cat << 'EOF' >> "$SYS_APP"
// === AutoX disclaimer Hook ===
systemApp.prototype._displayedDisclaimer = function() {
    framework.sendEventToMmui("system", "DisposeIntroVideo");
    framework.sendEventToMmui(this.uiaId, "Timeout");
};
// === AutoX disclaimer Hook End ===
EOF
                log_event "[PATCH] Injected simplified disclaimer skip hook into systemApp.js"
            fi
            
            sync
            mazda_watchdog_enable
            cmu_remount_ro
            release_lock
            echo "SUCCESS: $NAME enabled."
            ;;
        "disable"|"--disable")
            acquire_lock
            log_event "[START] Disabling $NAME"
            cmu_remount_rw
            mazda_watchdog_disable
            
            SYS_APP="/jci/gui/apps/system/js/systemApp.js"
            if [ -f "$SYS_APP" ]; then
                sed -i '/\/\/ === AutoX disclaimer Hook ===/,/\/\/ === AutoX disclaimer Hook End ===/d' "$SYS_APP" 2>/dev/null
                log_event "[HOOK] Removed disclaimer hook from systemApp.js"
            fi
            
            rm -f "$FLAG" 2>/dev/null
            
            sync
            mazda_watchdog_enable
            cmu_remount_ro
            release_lock
            echo "SUCCESS: $NAME disabled."
            ;;
        "shutdown")
            log_event "[SHUTDOWN] No active daemon to terminate for $NAME"
            ;;
        "uninstall")
            do_uninstall
            ;;
        "status"|"--status"|"-s")
            get_status
            ;;
        "raw"|"--raw")
            get_status
            ;;
        "meta"|"--meta")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"name\":\"$NAME\",\"title\":\"$TITLE\",\"subtitle\":\"$SUBTITLE\",\"author\":\"$AUTHOR\",\"category\":\"$CATEGORY\",\"order\":$ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":$SHOW_IN_GUI,\"install_state\":\"$INSTALL_STATE\"}"
            ;;
        "json"|"--json")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"usb\":\"${AUTOX_USB_ROOT:-NONE}\"}"
            ;;
        "help"|"--help"|"-h"|*)
            log_event "Started do_help/usage event"
            echo "$NAME $VERSION"
            echo "Usage: autox_${ID}.sh [install|reinstall|enable|disable|shutdown|uninstall|status|raw|meta|json|help]"
            ;;
    esac
}

execute_plugin "$@"
