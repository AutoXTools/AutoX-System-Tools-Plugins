#!/bin/sh
# ==============================================================================
# AutoX SSH Server Service Plugin - Standard Target Module (OpenSSH sshd)
# ==============================================================================
# Target Platform: Mazda Connect CMU FW 74.00.324 ONLY
# Architecture: ARMv7 / i.MX6 Dual/Quad SoC
# Security Notice: SSH provides root shell access over custom port 36000.
#                  Disable when not performing diagnostics to prevent exposure.
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

# --------------------------------------------------------------------------
# COMPILER BUILD DIRECTIVES (Non-Runtime Comments)
# --------------------------------------------------------------------------
# @directive hook_placement: eof
# @directive hook_placement_logic: 

TITLE="Enable SSH Service"
SUBTITLE="Open port 36000 for access"
ID="ssh"
NAME="SSH"
AUTHOR="AutoX"
CATEGORY="tweak"
ORDER=20
SHOW_IN_GUI="true"
VERSION="0.14"
INSTALL_STATE="disabled"
REBOOT_REQUIRED="false"
LONG_PRESS="false"

AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"

FLAG="$ENABLED_DIR/${ID}_enabled"
LOCK_FILE="/tmp/autox_${ID}.lock"
PLUGIN_TARGET="$PLUGINS_DIR/autox_${ID}.sh"
SCRIPT_PATH=$(readlink -f "$0" 2>/dev/null)
[ -z "$SCRIPT_PATH" ] && SCRIPT_PATH="$0"

SSH_RUN_LOG="$LOG_DIR/ssh.run.log"
SSHD_CONFIG="/tmp/autox_sshd_config"
SSH_RSA_KEY="$DATA_DIR/ssh_host_rsa_key"
STAGE_WIFI="/jci/scripts/stage_wifi.sh"

. /tmp/mnt/data_persist/autox/lib/autox_lib.sh

# --------------------------------------------------------------------------
# Summary: Firewall Port Opening Routine (Allows inbound network access)
# --------------------------------------------------------------------------
open_firewall_ports() {
    autox_log "$ID" "[FIREWALL] Opening TCP inbound port 36000 and ICMP on all interfaces..."
    echo 0 > /proc/sys/net/ipv4/icmp_echo_ignore_all 2>/dev/null
    sysctl -w net.ipv4.icmp_echo_ignore_all=0 2>/dev/null

    for port in 22 36000; do
        iptables -D INPUT -p tcp --dport "$port" -j ACCEPT 2>/dev/null
        iptables -D INPUT -i wlan0 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
        iptables -D INPUT -i eth0 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
    done
    iptables -D INPUT -p icmp -j ACCEPT 2>/dev/null
    iptables -D INPUT -i wlan0 -p icmp -j ACCEPT 2>/dev/null
    iptables -D INPUT -i eth0 -p icmp -j ACCEPT 2>/dev/null

    iptables -I INPUT 1 -p tcp --dport 36000 -j ACCEPT 2>/dev/null
    iptables -I INPUT 1 -i wlan0 -p tcp --dport 36000 -j ACCEPT 2>/dev/null
    iptables -I INPUT 1 -i eth0 -p tcp --dport 36000 -j ACCEPT 2>/dev/null
    iptables -I INPUT 1 -p icmp -j ACCEPT 2>/dev/null
    iptables -I INPUT 1 -i wlan0 -p icmp -j ACCEPT 2>/dev/null
    iptables -I INPUT 1 -i eth0 -p icmp -j ACCEPT 2>/dev/null
}

# --------------------------------------------------------------------------
# Summary: Firewall Lockdown Routine (Closes inbound network ports)
# --------------------------------------------------------------------------
close_firewall_ports() {
    autox_log "$ID" "[FIREWALL] Closing TCP inbound ports 22 & 36000 and ICMP..."
    for port in 22 36000; do
        iptables -D INPUT -p tcp --dport "$port" -j ACCEPT 2>/dev/null
        iptables -D INPUT -i wlan0 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
        iptables -D INPUT -i eth0 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
    done
    iptables -D INPUT -p icmp -j ACCEPT 2>/dev/null
    iptables -D INPUT -i wlan0 -p icmp -j ACCEPT 2>/dev/null
    iptables -D INPUT -i eth0 -p icmp -j ACCEPT 2>/dev/null
}

# --------------------------------------------------------------------------
# Summary: Persistent RSA Host Key Provisioning Routine
# --------------------------------------------------------------------------
ensure_host_keys() {
    mkdir -p "$DATA_DIR" 2>/dev/null
    if [ ! -f "$SSH_RSA_KEY" ] || [ ! -s "$SSH_RSA_KEY" ]; then
        autox_log "$ID" "[KEYS] Generating persistent OpenSSH RSA host key in $SSH_RSA_KEY..."
        if [ ! -x /usr/bin/ssh-keygen ]; then
            autox_log "$ID" "[ERROR] /usr/bin/ssh-keygen not found. Cannot provision host key."
            return 1
        fi
        /usr/bin/ssh-keygen -t rsa -N "" -f "$SSH_RSA_KEY" >/dev/null 2>&1
        if [ ! -f "$SSH_RSA_KEY" ] || [ ! -s "$SSH_RSA_KEY" ]; then
            autox_log "$ID" "[ERROR] Failed writing persistent RSA host key to $SSH_RSA_KEY."
            return 1
        fi
    fi
    chmod 600 "$SSH_RSA_KEY" 2>/dev/null
    return 0
}

# --------------------------------------------------------------------------
# Summary: Daemon Lifecycle Start Handler (Launches OpenSSH sshd)
# --------------------------------------------------------------------------
start_ssh_daemon() {
    autox_log "$ID" "[DAEMON] Initializing OpenSSH sshd on port 36000..."
    if [ ! -x /usr/sbin/sshd ]; then
        autox_log "$ID" "[ERROR] /usr/sbin/sshd not found. Cannot start SSH daemon."
        return 1
    fi

    if ! ensure_host_keys; then
        return 1
    fi

    open_firewall_ports
    mkdir -p /var/empty 2>/dev/null
    cat << EOF > "$SSHD_CONFIG"
Port 36000
Protocol 2
HostKey $SSH_RSA_KEY
UsePrivilegeSeparation no
PermitRootLogin yes
PasswordAuthentication yes
PermitEmptyPasswords yes
ChallengeResponseAuthentication no
UsePAM no
Subsystem sftp /usr/libexec/sftp-server
EOF
    if [ ! -s "$SSHD_CONFIG" ]; then
        autox_log "$ID" "[ERROR] Failed writing $SSHD_CONFIG."
        return 1
    fi

    killall -9 sshd 2>/dev/null
    /usr/sbin/sshd -f "$SSHD_CONFIG" >> "$SSH_RUN_LOG" 2>&1
    sleep 1
    if ! pidof sshd >/dev/null 2>&1; then
        autox_log "$ID" "[ERROR] OpenSSH sshd failed to stay running on port 36000."
        return 1
    fi

    autox_log "$ID" "[OK] OpenSSH sshd active on port 36000 (PID: $(pidof sshd))."
    return 0
}

# --------------------------------------------------------------------------
# Summary: Daemon Lifecycle Stop Handler (Shuts down OpenSSH sshd)
# --------------------------------------------------------------------------
stop_ssh_daemon() {
    autox_log "$ID" "[DAEMON] Shutting down OpenSSH sshd and closing port 36000..."
    killall -9 sshd 2>/dev/null
    close_firewall_ports
    rm -f "$SSHD_CONFIG" 2>/dev/null
    autox_log "$ID" "[STATUS] SSH Server Service stopped (Port 36000 closed)."
}

# --------------------------------------------------------------------------
# Summary: Comprehensive Diagnostic & Troubleshooting Suite
# --------------------------------------------------------------------------
run_ssh_diag() {
    _NOW=$(date 2>/dev/null)
    [ -z "$_NOW" ] && _NOW="N/A"
    echo "=========================================================================="
    echo "AutoX SSH Service Diagnostic & Troubleshooting Suite"
    echo "Target: Mazda Connect CMU FW 74.00.324 | Date: $_NOW"
    echo "=========================================================================="

    echo ""
    echo "[1] Network Interfaces & IP Addresses:"
    for iface in wlan0 eth0 lo; do
        if ifconfig "$iface" >/dev/null 2>&1; then
            IP=$(ifconfig "$iface" 2>/dev/null | awk -F'inet addr:' '{print $2}' | awk '{print $1}')
            [ -z "$IP" ] && IP=$(ifconfig "$iface" 2>/dev/null | awk '/inet / {print $2}')
            STATE="DOWN"
            if ifconfig "$iface" 2>/dev/null | grep -q "UP"; then
                STATE="UP"
            fi
            echo "  - $iface: $STATE (IP: ${IP:-None/Unassigned})"
        else
            echo "  - $iface: Not Present"
        fi
    done

    echo ""
    echo "[2] OpenSSH Binary Detection:"
    for bin in /usr/sbin/sshd /usr/bin/ssh-keygen /usr/sbin/iptables; do
        if [ -x "$bin" ]; then
            echo "  - $bin: AVAILABLE (Executable)"
        elif command -v "$bin" >/dev/null 2>&1; then
            echo "  - $bin: AVAILABLE ($(command -v "$bin"))"
        else
            echo "  - $bin: NOT FOUND"
        fi
    done

    echo ""
    echo "[3] Active SSH Processes (PIDs):"
    P_SSHD=$(pidof sshd 2>/dev/null)
    echo "  - OpenSSH sshd PID(s): ${P_SSHD:-Not Running}"

    echo ""
    echo "[4] Listening TCP Port (36000):"
    if [ -f /proc/net/tcp ]; then
        if grep -qi "8CA0" /proc/net/tcp 2>/dev/null; then
            echo "  Found active listening socket in /proc/net/tcp matching port 36000 (0x8CA0)."
        else
            echo "  No open socket for port 36000 in /proc/net/tcp."
        fi
    else
        echo "  /proc/net/tcp unavailable."
    fi

    echo ""
    echo "[5] Persistent Host Key Status:"
    if [ -f "$SSH_RSA_KEY" ]; then
        KSIZE=$(wc -c < "$SSH_RSA_KEY" 2>/dev/null)
        echo "  - $SSH_RSA_KEY: FOUND (${KSIZE:-0} bytes)"
    else
        echo "  - $SSH_RSA_KEY: Not Found"
    fi
}

# --------------------------------------------------------------------------
# Summary: Runtime Execution State Query (Returns "ENABLED" | "DISABLED")
# --------------------------------------------------------------------------
get_status() {
    if [ -f "$FLAG" ]; then
        echo "ENABLED"
    else
        echo "DISABLED"
    fi
}

# --------------------------------------------------------------------------
# Summary: Machine-Readable Diagnostic Manifest (RFC 8259 JSON Output)
# --------------------------------------------------------------------------
do_status_json() {
    _STAT=$(get_status)
    _ENABLED_BOOL="false"
    [ "$_STAT" = "ENABLED" ] && _ENABLED_BOOL="true"
    _PID_INFO=$(pidof sshd 2>/dev/null)
    cat << EOF
{
  "plugin": "autox_${ID}",
  "id": "$ID",
  "name": "$NAME",
  "title": "$TITLE",
  "status": "$_STAT",
  "enabled": $_ENABLED_BOOL,
  "daemon": "openssh",
  "port": 36000,
  "pid": "${_PID_INFO:-none}",
  "version": "$VERSION"
}
EOF
}

# --------------------------------------------------------------------------
# Summary: First-Run Deployment Routine (NAND Staging & Permission Hardening)
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    autox_log "$ID" "[START] $TITLE v$VERSION Installation Initiated"
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR" 2>/dev/null
    chmod 755 "$PLUGIN_TARGET" 2>/dev/null

    _STATE=$(echo "$INSTALL_STATE" | tr "[:upper:]" "[:lower:]")
    case "$_STATE" in
        "enabled"|"enable"|"1"|"true")
            release_lock
            do_enable "$1"
            return $?
            ;;
        *)
            rm -f "$FLAG" 2>/dev/null
            autox_log "$ID" "[COMPLETED] $TITLE v$VERSION staged (disabled)."
            release_lock
            echo "SUCCESS: $TITLE installed (disabled)."
            ;;
    esac
    return 0
}

# --------------------------------------------------------------------------
# Summary: In-Place Upgrade Handler (Version Matching & Safe State Preservation)
# --------------------------------------------------------------------------
do_reinstall() {
    FORCE=0
    [ "$1" = "--force" ] || [ "$2" = "--force" ] && FORCE=1

    if [ "$SCRIPT_PATH" = "$PLUGIN_TARGET" ]; then
        autox_log "$ID" "[ERROR] Cannot reinstall directly from installed target path $PLUGIN_TARGET."
        return 1
    fi

    CUR_VER="0"
    if [ -f "$PLUGIN_TARGET" ]; then
        CUR_VER=$("/bin/sh" "$PLUGIN_TARGET" version 2>/dev/null)
        [ -z "$CUR_VER" ] && CUR_VER="0"
    fi
    if [ "$CUR_VER" = "$VERSION" ] && [ $FORCE -eq 0 ]; then
        autox_log "$ID" "[SKIP] $ID already at v$VERSION. Skipping in-place rewrite."
        return 0
    fi

    WAS_ENABLED=0
    [ -f "$FLAG" ] && WAS_ENABLED=1

    if [ -f "$PLUGIN_TARGET" ]; then
        if ! /bin/sh "$PLUGIN_TARGET" disable; then
            autox_log "$ID" "[ERROR] Failed disabling prior $ID hooks prior to upgrade."
            return 1
        fi
    fi

    if ! cmu_verify_persist_rw; then
        autox_log "$ID" "[ERROR] Persistent flash /tmp/mnt/data_persist is not writable."
        return 1
    fi

    if ! cp -f "$SCRIPT_PATH" "$PLUGIN_TARGET"; then
        autox_log "$ID" "[ERROR] Failed copying $SCRIPT_PATH to $PLUGIN_TARGET."
        return 1
    fi
    chmod 755 "$PLUGIN_TARGET" 2>/dev/null
    sync

    if ! /bin/sh "$PLUGIN_TARGET" install; then
        autox_log "$ID" "[ERROR] Failed installing upgraded $ID payload."
        return 1
    fi

    if [ $WAS_ENABLED -eq 1 ]; then
        if ! /bin/sh "$PLUGIN_TARGET" enable --staged; then
            autox_log "$ID" "[ERROR] Upgraded $ID failed staged re-enable."
            return 1
        fi
    fi
    autox_log "$ID" "[REINSTALL] Successfully updated $ID to v$VERSION."
    return 0
}

# --------------------------------------------------------------------------
# Summary: Remove Hooks Routine
# --------------------------------------------------------------------------
remove_hooks() {
    TMP_STRIP="/tmp/autox_${ID}_strip.tmp"
    TMP_FILE="/tmp/autox_${ID}_rm.tmp"

    STAGE_1="/jci/scripts/stage_1.sh"
    for _TGT in "$STAGE_WIFI" "$STAGE_1"; do
        if [ -s "$_TGT" ]; then
            if grep -q '# === AutoX ssh Insertion Hook ===' "$_TGT" 2>/dev/null; then
                if ! grep -q '# === AutoX ssh Insertion Hook End ===' "$_TGT" 2>/dev/null; then
                    autox_log "$ID" "[ERROR] Unclosed ssh hook marker in $_TGT; aborting teardown."
                    return 1
                fi
                sed '/# === AutoX ssh Insertion Hook ===/,/# === AutoX ssh Insertion Hook End ===/d' "$_TGT" > "$TMP_STRIP" 2>/dev/null
                if [ $? -ne 0 ]; then
                    rm -f "$TMP_STRIP" "$TMP_FILE"
                    autox_log "$ID" "[ERROR] Failed stripping ssh hook from $_TGT in /tmp."
                    return 1
                fi
                awk '{ if (/^[ \t\r]*$/) { buf = buf "\n" } else { printf "%s%s\n", buf, $0; buf = "" } }' "$TMP_STRIP" > "$TMP_FILE" 2>/dev/null
                if [ $? -eq 0 ] && [ -s "$TMP_FILE" ] && cp -f "$TMP_FILE" "$_TGT"; then
                    rm -f "$TMP_STRIP" "$TMP_FILE"
                    autox_log "$ID" "[HOOK] Removed ssh hook & trailing blank lines from $_TGT"
                else
                    rm -f "$TMP_STRIP" "$TMP_FILE"
                    autox_log "$ID" "[ERROR] Failed staging clean $_TGT in /tmp."
                    return 1
                fi
            fi

            if grep -q '# === AutoX SSH Server Boot Hook ===' "$_TGT" 2>/dev/null; then
                if ! grep -q '# === AutoX SSH Server Boot Hook End ===' "$_TGT" 2>/dev/null; then
                    autox_log "$ID" "[ERROR] Unclosed legacy SSH Server Boot Hook marker in $_TGT; aborting teardown."
                    return 1
                fi
                sed '/# === AutoX SSH Server Boot Hook ===/,/# === AutoX SSH Server Boot Hook End ===/d' "$_TGT" > "$TMP_STRIP" 2>/dev/null
                awk '{ if (/^[ \t\r]*$/) { buf = buf "\n" } else { printf "%s%s\n", buf, $0; buf = "" } }' "$TMP_STRIP" > "$TMP_FILE" 2>/dev/null
                if [ $? -eq 0 ] && [ -s "$TMP_FILE" ] && cp -f "$TMP_FILE" "$_TGT"; then
                    rm -f "$TMP_STRIP" "$TMP_FILE"
                    autox_log "$ID" "[HOOK] Cleaned legacy SSH Server Boot Hook from $_TGT"
                else
                    rm -f "$TMP_STRIP" "$TMP_FILE"
                    autox_log "$ID" "[ERROR] Failed staging clean $_TGT after legacy hook strip."
                    return 1
                fi
            fi
        fi
    done
    return 0
}

# --------------------------------------------------------------------------
# Summary: Persistent Service Activation (Hook Injection & Recovery Suppression)
# --------------------------------------------------------------------------
do_enable() {
    _STAGED=0
    [ "$1" = "--staged" ] && _STAGED=1

    acquire_lock
    autox_log "$ID" "[START] Enabling $TITLE"
    cmu_remount_rw
    mazda_watchdog_disable

    if ! remove_hooks; then
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    if [ ! -f "$STAGE_WIFI" ]; then
        autox_log "$ID" "[ERROR] Missing target file $STAGE_WIFI"
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    printf '# === AutoX %s Insertion Hook === v%s\n' "$ID" "${VERSION#v}" >> "$STAGE_WIFI"
    cat << 'EOF' >> "$STAGE_WIFI"
if [ -f /tmp/mnt/data_persist/autox/plugins/enabled/ssh_enabled ] && [ -f /tmp/mnt/data_persist/autox/plugins/autox_ssh.sh ]; then
    /bin/sh /tmp/mnt/data_persist/autox/plugins/autox_ssh.sh start > /tmp/mnt/data_persist/autox/logs/ssh.run.log 2>&1 &
fi
# === AutoX ssh Insertion Hook End ===
EOF
    _HOOK_START=$(grep -c '# === AutoX ssh Insertion Hook ===' "$STAGE_WIFI" 2>/dev/null)
    _HOOK_END=$(grep -c '# === AutoX ssh Insertion Hook End ===' "$STAGE_WIFI" 2>/dev/null)
    if [ $? -ne 0 ] || [ "$_HOOK_START" != "1" ] || [ "$_HOOK_END" != "1" ]; then
        autox_log "$ID" "[ERROR] Failed injecting or verifying single ssh boot hook in $STAGE_WIFI"
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    if [ $_STAGED -eq 0 ]; then
        if ! start_ssh_daemon; then
            remove_hooks
            sync
            mazda_watchdog_enable
            cmu_remount_ro
            release_lock
            return 1
        fi
    fi

    touch "$FLAG" 2>/dev/null
    autox_log "$ID" "[HOOK] Injected single ssh boot hook into $STAGE_WIFI"

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock

    if [ "$REBOOT_REQUIRED" = "true" ]; then
        autox_log "$ID" "[REBOOT] $TITLE requires CMU reboot to take effect."
        echo "SUCCESS: $TITLE enabled. [REBOOT_REQUIRED=true]"
    else
        echo "SUCCESS: $TITLE enabled."
    fi
    return 0
}

# --------------------------------------------------------------------------
# Summary: Service Deactivation (Process Termination & Hook Deletion)
# --------------------------------------------------------------------------
do_disable() {
    acquire_lock
    autox_log "$ID" "[START] Disabling $TITLE"
    cmu_remount_rw
    mazda_watchdog_disable

    if ! remove_hooks; then
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi
    stop_ssh_daemon
    rm -f "$FLAG" 2>/dev/null

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: $TITLE disabled."
    return 0
}

# --------------------------------------------------------------------------
# Summary: Total Plugin Purge (Hook Removal, Process Kill & Target Script Deletion)
# --------------------------------------------------------------------------
do_uninstall() {
    acquire_lock
    autox_log "$ID" "[START] Uninstalling $TITLE"
    cmu_remount_rw
    mazda_watchdog_disable

    stop_ssh_daemon
    if ! remove_hooks; then
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    rm -f "$FLAG" "$SSHD_CONFIG" "$LOCK_FILE" "$PLUGIN_TARGET" 2>/dev/null

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: Plugin uninstalled."
    return 0
}

# --------------------------------------------------------------------------
# Summary: Master CLI Action Router & Framework Dispatcher
# --------------------------------------------------------------------------
execute_plugin() {
    _ACTION="$1"
    case "$_ACTION" in
        "version"|"--version")
            echo "$VERSION"
            ;;
        "install"|"--install"|"-i")
            do_install "$2"
            ;;
        "reinstall")
            do_reinstall "$2" "$3"
            ;;
        "toggle"|"--toggle")
            if [ -f "$FLAG" ]; then
                execute_plugin "disable"
            else
                execute_plugin "enable"
            fi
            ;;
        "enable"|"--enable")
            do_enable "$2"
            ;;
        "disable"|"--disable")
            do_disable
            ;;
        "start"|"--start")
            start_ssh_daemon
            ;;
        "stop"|"--stop")
            stop_ssh_daemon
            ;;
        "restart"|"--restart"|"reload")
            stop_ssh_daemon
            sleep 1
            start_ssh_daemon
            ;;
        "diag"|"--diag"|"diagnose"|"doctor"|"report"|"test"|"--test")
            run_ssh_diag
            ;;
        "debug"|"--debug")
            if [ ! -x /usr/sbin/sshd ]; then
                autox_log "$ID" "[ERROR] /usr/sbin/sshd not found."
                return 1
            fi
            ensure_host_keys || return 1
            open_firewall_ports
            killall -9 sshd 2>/dev/null
            /usr/sbin/sshd -D -e -p 36000 -h "$SSH_RSA_KEY"
            ;;
        "shutdown"|"--shutdown")
            autox_log "$ID" "[SHUTDOWN] Stopping running OpenSSH sshd immediately..."
            stop_ssh_daemon
            ;;
        "uninstall"|"--uninstall"|"-u")
            do_uninstall
            ;;
        "status"|"--status"|"-s")
            get_status
            ;;
        "raw"|"--raw")
            get_status
            ;;
        "meta"|"--meta"|"info"|"--info")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"title\":\"$TITLE\",\"subtitle\":\"$SUBTITLE\",\"author\":\"$AUTHOR\",\"category\":\"$CATEGORY\",\"order\":$ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":$SHOW_IN_GUI,\"install_state\":\"$INSTALL_STATE\",\"reboot_required\":$REBOOT_REQUIRED,\"long_press\":$LONG_PRESS}"
            ;;
        "json"|"--json")
            do_status_json
            ;;
        "help"|"--help"|"-h"|*)
            autox_log "$ID" "Started do_help/usage event"
            echo "$TITLE v$VERSION"
            echo "Usage: autox_${ID}.sh [install|reinstall|toggle|enable|disable|start|stop|restart|diag|debug|shutdown|uninstall|status|raw|meta|json|version|help]"
            ;;
    esac
}

execute_plugin "$@"
