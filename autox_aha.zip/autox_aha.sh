#!/bin/sh
# ==============================================================================
# AutoX Application Runner Framework Plugin - Standard Target Module
# ==============================================================================
# Target Platform: Mazda Connect CMU FW 74.00.324 ONLY
# Architecture: ARMv7 / i.MX6 Dual/Quad SoC
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

# --------------------------------------------------------------------------
# COMPILER BUILD DIRECTIVES (Non-Runtime Comments)
# --------------------------------------------------------------------------
# @directive hook_placement: custom
# @directive hook_placement_logic: In-place line swap via /tmp-staged single-pass awk; every anchor line is replaced by an id-pinned hook holding the OEM line (XML: %25/%2D-encoded) as an "AutoX aha OEM:" comment plus its patched form, with exact per-anchor match counts: sm.conf + sm_WCP.conf name="blm_ira_aha" x1 (autorun="yes" -> autorun="no") and value="blm_ira_aha" x3 (-> value="stage_ir" | value="bds" | value="audio_manager", one line each); mmui_config.xml uiaid="30" name="aharadio" x1 (OEM line commented out); cpp_offboard-system.xml key="Aha" x1 (OEM line commented out); GuiResources.js "aharadio" : true x1 (true -> false); abort and roll back on any count mismatch.

# --------------------------------------------------------------------------
# 1. MANDATORY METADATA MANIFEST
# --------------------------------------------------------------------------
TITLE="Disable Aha Service"
SUBTITLE="Improved system bootup experience"
ID="aha"
NAME="AHA"
AUTHOR="AutoX Developer Network"
CATEGORY="tweak"
ORDER=51
SHOW_IN_GUI="true"
VERSION="0.11"
INSTALL_STATE="disabled"
REBOOT_REQUIRED="true"
LONG_PRESS="false"

# --------------------------------------------------------------------------
# 2. DETERMINISTIC TOPOLOGY PATHS
# --------------------------------------------------------------------------
AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"

FLAG="$ENABLED_DIR/${ID}_enabled"
LOCK_FILE="/tmp/autox_${ID}.lock"
PLUGIN_TARGET="$PLUGINS_DIR/autox_${ID}.sh"
SCRIPT_PATH=$(readlink -f "$0" 2>/dev/null)
[ -z "$SCRIPT_PATH" ] && SCRIPT_PATH="$0"

FW_INI="/jci/version.ini"
FW_REQUIRED="74.00.324"
GUIRES_JS="/jci/gui/resources/js/GuiResources.js"
SM_CONF="/jci/sm/sm.conf"
SM_WCP_CONF="/jci/sm/sm_WCP.conf"
MMUI_XML="/jci/mmui/mmui_config.xml"
OFFBOARD_XML="/jci/settings/configurations/cpp_offboard-system.xml"

TMP_INS="/tmp/autox_${ID}_ins.tmp"
TMP_FILE="/tmp/autox_${ID}_rm.tmp"

# --------------------------------------------------------------------------
# 3. CENTRALIZED AUTOX RUNTIME LIBRARY
# --------------------------------------------------------------------------
. /tmp/mnt/data_persist/autox/lib/autox_lib.sh

# --------------------------------------------------------------------------
# Summary: Check Firmware Routine (Validates target CMU FW version)
# --------------------------------------------------------------------------
check_firmware() {
    if [ ! -f "$FW_INI" ]; then
        autox_log "$ID" "[ERROR] Missing $FW_INI; cannot verify firmware $FW_REQUIRED."
        return 1
    fi
    if ! grep -q '^JCI_SW_VER="[^"]*_74\.00\.324"' "$FW_INI" 2>/dev/null; then
        autox_log "$ID" "[ERROR] Firmware is not $FW_REQUIRED ($(grep '^JCI_SW_VER=' "$FW_INI" 2>/dev/null)); aborting."
        return 1
    fi
    return 0
}

# --------------------------------------------------------------------------
# Summary: Hook Tokens Routine (Defines comment markers based on file type)
# --------------------------------------------------------------------------
hook_tokens() {
    if [ "$1" = "xml" ]; then
        _CO="<!--"
        _CC=" -->"
    else
        _CO="//"
        _CC=""
    fi
    _MS="$_CO === AutoX aha Insertion Hook ==="
    _ME="$_CO === AutoX aha Insertion Hook End ==="
    _OP="$_CO AutoX aha OEM: "
}

# --------------------------------------------------------------------------
# Summary: Strip File Routine (Strips bounded AutoX hooks from OEM files)
# --------------------------------------------------------------------------
strip_file() {
    _SF_TARGET="$1"
    hook_tokens "$2"
    [ -s "$_SF_TARGET" ] || return 0
    _SF_START=$(grep -cF "$_MS" "$_SF_TARGET" 2>/dev/null)
    [ -z "$_SF_START" ] && _SF_START=0
    [ "$_SF_START" -eq 0 ] && return 0
    _SF_END=$(grep -cF "$_ME" "$_SF_TARGET" 2>/dev/null)
    [ -z "$_SF_END" ] && _SF_END=0
    if [ "$_SF_START" -ne "$_SF_END" ]; then
        autox_log "$ID" "[ERROR] Unbalanced aha hook markers in $_SF_TARGET; aborting teardown."
        return 1
    fi
    awk -v ms="$_MS" -v me="$_ME" -v op="$_OP" -v cc="$_CC" '
    function dec(s) {
        if (cc != "") { gsub(/%2D/, "-", s); gsub(/%25/, "%", s) }
        return s
    }
    function out(l) {
        if (l ~ /^[ \t\r]*$/) { buf = buf l "\n" } else { printf "%s%s\n", buf, l; buf = "" }
    }
    BEGIN { inb = 0; buf = "" }
    !inb && index($0, ms) > 0 { inb = 1; next }
    inb && index($0, me) > 0 { inb = 0; next }
    inb {
        if (index($0, op) == 1) {
            s = substr($0, length(op) + 1)
            n = length(s) - length(cc)
            if (cc != "" && n >= 0 && substr(s, n + 1) == cc) s = substr(s, 1, n)
            out(dec(s))
        }
        next
    }
    { out($0) }
    END { if (inb) exit 2 }
    ' "$_SF_TARGET" > "$TMP_FILE" 2>/dev/null
    if [ $? -eq 0 ] && [ -s "$TMP_FILE" ]; then
        cp -f "$TMP_FILE" "$_SF_TARGET"
        rm -f "$TMP_FILE"
        autox_log "$ID" "[HOOK] Restored OEM lines from $_SF_TARGET"
    else
        rm -f "$TMP_FILE"
        autox_log "$ID" "[ERROR] Failed staging clean $_SF_TARGET"
        return 1
    fi
    return 0
}

# --------------------------------------------------------------------------
# Summary: Insert File Routine (Injects bounded hooks into OEM files)
# --------------------------------------------------------------------------
insert_file() {
    _IF_TARGET="$1"
    hook_tokens "$2"
    _IF_EXPECT="$3"
    shift 3
    if [ ! -f "$_IF_TARGET" ]; then return 1; fi
    awk -v ver="v${VERSION#v}" -v co="$_CO" -v cc="$_CC" \
        -v a1="$1" -v f1="$2" -v t1="$3" -v n1="$4" \
        -v a2="$5" -v f2="$6" -v t2="$7" -v n2="$8" '
    function enc(s) { if (cc != "") { gsub(/%/, "%25", s); gsub(/-/, "%2D", s) }; return s }
    function swap(line, from, to,    p, k, i, parts) {
        print co " === AutoX aha Insertion Hook === " ver cc
        print co " AutoX aha OEM: " enc(line) cc
        if (from != "") {
            p = index(line, from)
            if (p == 0) { bad = 1 } else {
                k = split(to, parts, "|")
                for (i = 1; i <= k; i++) print substr(line, 1, p - 1) parts[i] substr(line, p + length(from))
            }
        }
        print co " === AutoX aha Insertion Hook End ===" cc
    }
    BEGIN { c1 = 0; c2 = 0; bad = 0 }
    a1 != "" && index($0, a1) > 0 { swap($0, f1, t1); c1++; next }
    a2 != "" && index($0, a2) > 0 { swap($0, f2, t2); c2++; next }
    { print }
    END { if (bad) exit 3; if (a1 != "" && c1 != n1 + 0) exit 1; if (a2 != "" && c2 != n2 + 0) exit 1 }
    ' "$_IF_TARGET" > "$TMP_INS" 2>/dev/null
    _IF_RC=$?
    if [ $_IF_RC -ne 0 ] || [ ! -s "$TMP_INS" ]; then rm -f "$TMP_INS"; return 1; fi
    cp -f "$TMP_INS" "$_IF_TARGET" && rm -f "$TMP_INS"
    return 0
}

# --------------------------------------------------------------------------
# Summary: Remove Hooks Routine (Unified teardown helper)
# --------------------------------------------------------------------------
remove_hooks() {
    strip_file "$GUIRES_JS" js
    strip_file "$SM_CONF" xml
    strip_file "$SM_WCP_CONF" xml
    strip_file "$MMUI_XML" xml
    strip_file "$OFFBOARD_XML" xml
}

# --------------------------------------------------------------------------
# Summary: Plugin Activation Routine (Injects hooks)
# --------------------------------------------------------------------------
do_enable() {
    acquire_lock
    autox_log "$ID" "[START] Enabling $TITLE"
    cmu_remount_rw; mazda_watchdog_disable
    if ! remove_hooks; then
        mazda_watchdog_enable; cmu_remount_ro; release_lock; return 1
    fi
    insert_file "$SM_CONF" xml 1 'name="blm_ira_aha"' 'autorun="yes"' 'autorun="no"' 1 'value="blm_ira_aha"' 'value="blm_ira_aha"' 'value="stage_ir"|value="bds"|value="audio_manager"' 3
    if [ -f "$SM_WCP_CONF" ]; then
        insert_file "$SM_WCP_CONF" xml 1 'name="blm_ira_aha"' 'autorun="yes"' 'autorun="no"' 1 'value="blm_ira_aha"' 'value="blm_ira_aha"' 'value="stage_ir"|value="bds"|value="audio_manager"' 3
    fi
    insert_file "$MMUI_XML" xml 1 'uiaid="30" name="aharadio"' '' '' 1 '' '' '' 0
    insert_file "$OFFBOARD_XML" xml 1 'key="Aha"' '' '' 1 '' '' '' 0
    insert_file "$GUIRES_JS" js 1 '"aharadio" : true' 'true' 'false' 1 '' '' '' 0
    touch "$FLAG"
    sync; mazda_watchdog_enable; cmu_remount_ro; release_lock
    echo "SUCCESS: $TITLE enabled. [REBOOT_REQUIRED=true]"
}

# --------------------------------------------------------------------------
# Summary: Plugin Deactivation Routine (Removes hooks)
# --------------------------------------------------------------------------
do_disable() {
    acquire_lock
    autox_log "$ID" "[START] Disabling $TITLE"
    cmu_remount_rw; mazda_watchdog_disable
    remove_hooks
    rm -f "$FLAG"
    sync; mazda_watchdog_enable; cmu_remount_ro; release_lock
    echo "SUCCESS: $TITLE disabled."
}

# --------------------------------------------------------------------------
# Summary: First-Run Deployment Routine (NAND Staging)
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    autox_log "$ID" "[START] $TITLE v$VERSION Installation Initiated"
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR"
    autox_log "$ID" "[COMPLETED] $TITLE v$VERSION successfully deployed."
    release_lock
}

# --------------------------------------------------------------------------
# Summary: Total Plugin Purge (Removes hooks and scripts)
# --------------------------------------------------------------------------
do_uninstall() {
    acquire_lock
    autox_log "$ID" "[START] Uninstalling $TITLE"
    cmu_remount_rw; mazda_watchdog_disable
    remove_hooks
    rm -f "$FLAG" "$PLUGIN_TARGET"
    sync; mazda_watchdog_enable; cmu_remount_ro; release_lock
    echo "SUCCESS: Plugin uninstalled."
}

# --------------------------------------------------------------------------
# Summary: In-Place Upgrade Handler
# --------------------------------------------------------------------------
do_reinstall() {
    FORCE=0
    [ "$1" = "--force" ] || [ "$2" = "--force" ] && FORCE=1
    if [ "$SCRIPT_PATH" = "$PLUGIN_TARGET" ]; then
        autox_log "$ID" "[ERROR] Cannot reinstall directly from installed target path $PLUGIN_TARGET."
        return 1
    fi
    CUR_VER="0"
    if [ -f "$PLUGIN_TARGET" ]; then
        CUR_VER=$(/bin/sh "$PLUGIN_TARGET" version 2>/dev/null)
        [ -z "$CUR_VER" ] && CUR_VER="0"
    fi
    if [ "$CUR_VER" = "$VERSION" ] && [ $FORCE -eq 0 ]; then
        autox_log "$ID" "[SKIP] $ID already at v$VERSION. Skipping in-place rewrite."
        return 0
    fi
    WAS_ENABLED=0
    [ -f "$FLAG" ] && WAS_ENABLED=1
    if [ -f "$PLUGIN_TARGET" ]; then
        if ! /bin/sh "$PLUGIN_TARGET" disable; then
            autox_log "$ID" "[ERROR] Failed disabling prior $ID hooks prior to upgrade."
            return 1
        fi
    fi
    if ! cmu_verify_persist_rw; then
        autox_log "$ID" "[ERROR] Persistent flash /tmp/mnt/data_persist is not writable."
        return 1
    fi
    if ! cp -f "$SCRIPT_PATH" "$PLUGIN_TARGET"; then
        autox_log "$ID" "[ERROR] Failed copying $SCRIPT_PATH to $PLUGIN_TARGET."
        return 1
    fi
    chmod 755 "$PLUGIN_TARGET" 2>/dev/null
    sync
    if ! /bin/sh "$PLUGIN_TARGET" install; then
        autox_log "$ID" "[ERROR] Failed installing upgraded $ID payload."
        return 1
    fi
    if [ $WAS_ENABLED -eq 1 ]; then
        if ! /bin/sh "$PLUGIN_TARGET" enable --staged; then
            autox_log "$ID" "[ERROR] Upgraded $ID failed staged re-enable."
            return 1
        fi
    fi
    autox_log "$ID" "[REINSTALL] Successfully updated $ID to v$VERSION."
}

# --------------------------------------------------------------------------
# Summary: Runtime Execution State Query
# --------------------------------------------------------------------------
get_status() {
    if [ -f "$FLAG" ]; then echo "ENABLED"; else echo "DISABLED"; fi
}

# --------------------------------------------------------------------------
# Summary: Master CLI Action Router & Framework Dispatcher
# --------------------------------------------------------------------------
execute_plugin() {
    _ACTION="$1"
    case "$_ACTION" in
        "version"|"--version") echo "$VERSION" ;;
        "install"|"--install") do_install ;;
        "reinstall") do_reinstall "$2" ;;
        "toggle"|"--toggle") 
            if [ -f "$FLAG" ]; then
                execute_plugin "disable"
            else
                execute_plugin "enable"
            fi 
            ;;
        "enable"|"--enable") do_enable "$2" ;;
        "disable"|"--disable") do_disable ;;
        "uninstall") do_uninstall ;;
        "status"|"--status"|"-s") get_status ;;
        "meta"|"--meta")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"title\":\"$TITLE\",\"subtitle\":\"$SUBTITLE\",\"author\":\"$AUTHOR\",\"category\":\"$CATEGORY\",\"order\":$ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":$SHOW_IN_GUI,\"install_state\":\"$INSTALL_STATE\",\"reboot_required\":$REBOOT_REQUIRED,\"long_press\":$LONG_PRESS}"
            ;;
        "json"|"--json")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"usb\":\"${USB_ROOT:-NONE}\"}"
            ;;
        "help"|"--help"|"-h"|*) 
            echo "$TITLE v$VERSION"
            echo "Usage: autox_${ID}.sh [install|reinstall|toggle|enable|disable|uninstall|status|meta|json|help]"
            ;;
    esac
}

execute_plugin "$@"