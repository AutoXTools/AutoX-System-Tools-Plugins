#!/bin/sh
# ==============================================================================
# AutoX Application Runner Framework Plugin - Standard Target Module
# ==============================================================================
# Target Platform: Mazda Connect CMU FW 74.00.324 ONLY
# Architecture: ARMv7 / i.MX6 Dual/Quad SoC
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

# --------------------------------------------------------------------------
# COMPILER BUILD DIRECTIVES (Non-Runtime Comments)
# --------------------------------------------------------------------------
# @directive hook_placement: custom
# @directive hook_placement_logic: In-place line swap via /tmp-staged single-pass awk; each anchor line is replaced by an id-pinned hook holding the verbatim OEM line as an "AutoX stitcher OEM:" comment plus its patched form

# --------------------------------------------------------------------------
# 1. MANDATORY METADATA MANIFEST
# --------------------------------------------------------------------------
TITLE="Disable Stitcher"
SUBTITLE="Hides Stitcher menu, stops irsstitcher/blm_ira_stitcher services"
ID="stitcher"
NAME="STITCHER"
AUTHOR="AutoX Developer Network"
CATEGORY="tweak"
ORDER=50
SHOW_IN_GUI="true"
VERSION="0.11"
INSTALL_STATE="disabled"
REBOOT_REQUIRED="true"
LONG_PRESS="false"

# --------------------------------------------------------------------------
# 2. DETERMINISTIC TOPOLOGY PATHS
# --------------------------------------------------------------------------
AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"

FLAG="$ENABLED_DIR/${ID}_enabled"
LOCK_FILE="/tmp/autox_${ID}.lock"
PLUGIN_TARGET="$PLUGINS_DIR/autox_${ID}.sh"
SCRIPT_PATH=$(readlink -f "$0" 2>/dev/null)
[ -z "$SCRIPT_PATH" ] && SCRIPT_PATH="$0"

FW_INI="/jci/version.ini"
FW_REQUIRED="74.00.324"
SYSAPP_JS="/jci/gui/apps/system/js/systemApp.js"
GUIRES_JS="/jci/gui/resources/js/GuiResources.js"
SM_CONF="/jci/sm/sm.conf"
SM_WCP_CONF="/jci/sm/sm_WCP.conf"
MMUI_XML="/jci/mmui/mmui_config.xml"
OFFBOARD_XML="/jci/settings/configurations/cpp_offboard-system.xml"

. /tmp/mnt/data_persist/autox/lib/autox_lib.sh

# --------------------------------------------------------------------------
# Summary: Check Firmware Routine (Validates target CMU version)
# --------------------------------------------------------------------------
check_firmware() {
    if [ ! -f "$FW_INI" ]; then
        autox_log "$ID" "[ERROR] Missing $FW_INI; cannot verify firmware $FW_REQUIRED."
        return 1
    fi
    if ! grep -q '^JCI_SW_VER="[^"]*_74\.00\.324"' "$FW_INI" 2>/dev/null; then
        autox_log "$ID" "[ERROR] Firmware is not $FW_REQUIRED ($(grep '^JCI_SW_VER=' "$FW_INI" 2>/dev/null)); aborting."
        return 1
    fi
    return 0
}

# --------------------------------------------------------------------------
# Summary: Runtime Execution State Query (Returns "ENABLED" | "DISABLED")
# --------------------------------------------------------------------------
get_status() {
    if [ -f "$FLAG" ]; then echo "ENABLED"; else echo "DISABLED"; fi
}

# --------------------------------------------------------------------------
# Summary: Hook Tokens Routine (Configures markers for patch injection)
# --------------------------------------------------------------------------
hook_tokens() {
    if [ "$1" = "xml" ]; then
        _CO="<!--"
        _CC=" -->"
    else
        _CO="//"
        _CC=""
    fi
    _MS="$_CO === AutoX stitcher Insertion Hook ==="
    _ME="$_CO === AutoX stitcher Insertion Hook End ==="
    _OP="$_CO AutoX stitcher OEM: "
}

# --------------------------------------------------------------------------
# Summary: Strip File Routine (Removes bounded patches using tmp buffers)
# --------------------------------------------------------------------------
strip_file() {
    _SF_TARGET="$1"
    hook_tokens "$2"
    TMP_FILE="/tmp/autox_${ID}_rm.tmp"
    [ -s "$_SF_TARGET" ] || return 0
    _SF_START=$(grep -cF "$_MS" "$_SF_TARGET" 2>/dev/null)
    [ -z "$_SF_START" ] && _SF_START=0
    [ "$_SF_START" -eq 0 ] && return 0
    _SF_END=$(grep -cF "$_ME" "$_SF_TARGET" 2>/dev/null)
    [ -z "$_SF_END" ] && _SF_END=0
    if [ "$_SF_START" -ne "$_SF_END" ]; then
        autox_log "$ID" "[ERROR] Unbalanced stitcher hook markers in $_SF_TARGET; aborting."
        return 1
    fi
    awk -v ms="$_MS" -v me="$_ME" -v op="$_OP" -v cc="$_CC" 'function out(l) { if (l ~ /^[ \t\r]*$/) { buf = buf l "\n" } else { printf "%s%s\n", buf, l; buf = "" } } BEGIN { inb = 0; buf = "" } !inb && index($0, ms) > 0 { inb = 1; next } inb && index($0, me) > 0 { inb = 0; next } inb { if (index($0, op) == 1) { s = substr($0, length(op) + 1); n = length(s) - length(cc); if (cc != "" && n >= 0 && substr(s, n + 1) == cc) s = substr(s, 1, n); out(s) } next } { out($0) } END { if (inb) exit 2 }' "$_SF_TARGET" > "$TMP_FILE" 2>/dev/null
    if [ $? -eq 0 ] && [ -s "$TMP_FILE" ]; then
        cp -f "$TMP_FILE" "$_SF_TARGET"
        rm -f "$TMP_FILE"
        autox_log "$ID" "[HOOK] Restored OEM lines in $_SF_TARGET"
        return 0
    else
        rm -f "$TMP_FILE"
        return 1
    fi
}

# --------------------------------------------------------------------------
# Summary: Insert File Routine (Injects patch markers and logic)
# --------------------------------------------------------------------------
insert_file() {
    _IF_TARGET="$1"
    hook_tokens "$2"
    _IF_EXPECT="$3"
    TMP_INS="/tmp/autox_${ID}_ins.tmp"
    awk -v ver="v${VERSION#v}" -v co="$_CO" -v cc="$_CC" -v a1="$4" -v f1="$5" -v t1="$6" -v a2="$7" -v f2="$8" -v t2="$9" 'function swap(line, from, to, p) { if (cc != "" && index(line, "--") > 0) bad = 1; print co " === AutoX stitcher Insertion Hook === " ver cc; print co " AutoX stitcher OEM: " line cc; if (from != "") { p = index(line, from); if (p == 0) bad = 1; else print substr(line, 1, p - 1) to substr(line, p + length(from)) } print co " === AutoX stitcher Insertion Hook End ===" cc } BEGIN { d1 = 0; d2 = 0; bad = 0 } a1 != "" && !d1 && index($0, a1) > 0 { swap($0, f1, t1); d1 = 1; next } a2 != "" && !d2 && index($0, a2) > 0 { swap($0, f2, t2); d2 = 1; next } { print } END { if (bad) exit 3; if (a1 != "" && !d1) exit 1; if (a2 != "" && !d2) exit 1 }' "$_IF_TARGET" > "$TMP_INS" 2>/dev/null
    if [ $? -eq 0 ] && [ -s "$TMP_INS" ]; then
        cp -f "$TMP_INS" "$_IF_TARGET"
        rm -f "$TMP_INS"
        return 0
    else
        rm -f "$TMP_INS"
        return 1
    fi
}

# --------------------------------------------------------------------------
# Summary: Shared Hook Teardown Helper (Delegates to strip_file)
# --------------------------------------------------------------------------
remove_hooks() {
    strip_file "$SYSAPP_JS" js && strip_file "$GUIRES_JS" js && strip_file "$SM_CONF" xml && strip_file "$SM_WCP_CONF" xml && strip_file "$MMUI_XML" xml && strip_file "$OFFBOARD_XML" xml
}

# --------------------------------------------------------------------------
# Summary: First-Run Deployment Routine (NAND Staging)
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    if ! check_firmware; then release_lock; return 1; fi
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR"
    release_lock
}

# --------------------------------------------------------------------------
# Summary: In-Place Upgrade Handler (Version Matching & Safe State Preservation)
# --------------------------------------------------------------------------
do_reinstall() {
    FORCE=0
    [ "$1" = "--force" ] || [ "$2" = "--force" ] && FORCE=1
    WAS_ENABLED=0
    [ -f "$FLAG" ] && WAS_ENABLED=1
    if [ "$SCRIPT_PATH" = "$PLUGIN_TARGET" ]; then
        autox_log "$ID" "[ERROR] Cannot reinstall directly from installed target path $PLUGIN_TARGET."
        return 1
    fi
    if [ -f "$PLUGIN_TARGET" ]; then
        if ! /bin/sh "$PLUGIN_TARGET" disable; then
            autox_log "$ID" "[ERROR] Failed disabling prior hooks prior to upgrade."
            return 1
        fi
    fi
    if ! cp -f "$SCRIPT_PATH" "$PLUGIN_TARGET"; then
        autox_log "$ID" "[ERROR] Failed copying to $PLUGIN_TARGET."
        return 1
    fi
    chmod 755 "$PLUGIN_TARGET"
    do_install
    [ $WAS_ENABLED -eq 1 ] && /bin/sh "$PLUGIN_TARGET" enable --staged
}

# --------------------------------------------------------------------------
# Summary: Plugin Activation Routine (Hooks injection)
# --------------------------------------------------------------------------
do_enable() {
    acquire_lock
    autox_log "$ID" "[START] Enabling $TITLE"
    cmu_remount_rw; mazda_watchdog_disable
    if ! remove_hooks; then
        mazda_watchdog_enable; cmu_remount_ro; release_lock; return 1
    fi
    if ! insert_file "$SYSAPP_JS" js 1 "appName : 'stitcher'" "isVisible : true" "isVisible : false"; then
        remove_hooks; mazda_watchdog_enable; cmu_remount_ro; release_lock; return 1
    fi
    if ! insert_file "$GUIRES_JS" js 1 '"stitcher": true' 'true' 'false'; then
        remove_hooks; mazda_watchdog_enable; cmu_remount_ro; release_lock; return 1
    fi
    if ! insert_file "$SM_CONF" xml 2 'name="irsstitcher_server"' 'autorun="yes"' 'autorun="no"' 'name="blm_ira_stitcher"' 'autorun="yes"' 'autorun="no"'; then
        remove_hooks; mazda_watchdog_enable; cmu_remount_ro; release_lock; return 1
    fi
    if ! insert_file "$SM_WCP_CONF" xml 2 'name="irsstitcher_server"' 'autorun="yes"' 'autorun="no"' 'name="blm_ira_stitcher"' 'autorun="yes"' 'autorun="no"'; then
        : 
    fi
    if ! insert_file "$MMUI_XML" xml 1 'uiaid="29" name="stitcher"' '' ''; then
        remove_hooks; mazda_watchdog_enable; cmu_remount_ro; release_lock; return 1
    fi
    if ! insert_file "$OFFBOARD_XML" xml 1 'key="Stitcher"' '' ''; then
        remove_hooks; mazda_watchdog_enable; cmu_remount_ro; release_lock; return 1
    fi
    touch "$FLAG"
    sync; mazda_watchdog_enable; cmu_remount_ro; release_lock
    if [ "$REBOOT_REQUIRED" = "true" ]; then
        autox_log "$ID" "[REBOOT] $TITLE requires CMU reboot to take effect."
        echo "SUCCESS: $TITLE enabled. [REBOOT_REQUIRED=true]"
    else
        echo "SUCCESS: $TITLE enabled."
    fi
}

# --------------------------------------------------------------------------
# Summary: Plugin Deactivation Routine (Strips hooks & cleanup)
# --------------------------------------------------------------------------
do_disable() {
    acquire_lock
    autox_log "$ID" "[START] Disabling $TITLE"
    cmu_remount_rw; mazda_watchdog_disable
    remove_hooks; rm -f "$FLAG"
    sync; mazda_watchdog_enable; cmu_remount_ro; release_lock
    echo "SUCCESS: $TITLE disabled."
}

# --------------------------------------------------------------------------
# Summary: Plugin Uninstall Routine (Full NAND revert)
# --------------------------------------------------------------------------
do_uninstall() {
    acquire_lock
    autox_log "$ID" "[START] Uninstalling $TITLE"
    cmu_remount_rw; mazda_watchdog_disable
    remove_hooks; rm -f "$FLAG" "$PLUGIN_TARGET"
    sync; mazda_watchdog_enable; cmu_remount_ro; release_lock
    echo "SUCCESS: Plugin uninstalled."
}

# --------------------------------------------------------------------------
# Summary: Master CLI Action Router & Framework Dispatcher
# --------------------------------------------------------------------------
execute_plugin() {
    case "$1" in
        "version"|"--version") echo "$VERSION" ;;
        "install"|"--install") do_install ;;
        "reinstall") do_reinstall "$2" ;;
        "toggle"|"--toggle")
            if [ -f "$FLAG" ]; then execute_plugin "disable"; else execute_plugin "enable"; fi ;;
        "enable"|"--enable") do_enable ;;
        "disable"|"--disable") do_disable ;;
        "shutdown") autox_log "$ID" "[SHUTDOWN] No daemon service to terminate." ;;
        "uninstall") do_uninstall ;;
        "status"|"--status"|"-s") get_status ;;
        "meta"|"--meta")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"title\":\"$TITLE\",\"subtitle\":\"$SUBTITLE\",\"author\":\"$AUTHOR\",\"category\":\"$CATEGORY\",\"order\":$ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":$SHOW_IN_GUI,\"install_state\":\"$INSTALL_STATE\",\"reboot_required\":$REBOOT_REQUIRED,\"long_press\":$LONG_PRESS}" ;;
        "json"|"--json")
            _STAT=$(get_status)
            echo "{\"id\":\"$ID\",\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"usb\":\"${USB_ROOT:-NONE}\"}" ;;
        "help"|"--help"|"-h"|*) echo "Usage: $0 [install|reinstall|toggle|enable|disable|shutdown|uninstall|status|meta|json|help]" ;;
    esac
}

execute_plugin "$@"