#!/bin/sh
# ==============================================================================
# AutoX Application Runner Framework Plugin - Wi-Fi Multi-Mode Service
# ==============================================================================
# Target Platform: Mazda Connect CMU FW 74.00.324 ONLY
# Architecture: ARMv7 / i.MX6 Dual/Quad SoC
# ==============================================================================

PATH=/bin:/usr/bin:/sbin:/usr/sbin:$PATH
export PATH

# --------------------------------------------------------------------------
# COMPILER BUILD DIRECTIVES (Non-Runtime Comments)
# --------------------------------------------------------------------------
# @directive hook_placement: eof
# @directive hook_placement_logic: 

TITLE="Wi-Fi Service"
SUBTITLE="Enable/disable CMU Wi-Fi adapter"
ID="wifi"
NAME="WIFI"
AUTHOR="AutoX Developer Network"
CATEGORY="tweak"
ORDER=10
SHOW_IN_GUI="true"
VERSION="0.13"
INSTALL_STATE="disabled"
REBOOT_REQUIRED="false"
LONG_PRESS="true"

AUTOX_DIR="/tmp/mnt/data_persist/autox"
PLUGINS_DIR="$AUTOX_DIR/plugins"
ENABLED_DIR="$PLUGINS_DIR/enabled"
LOG_DIR="$AUTOX_DIR/logs"
DATA_DIR="$AUTOX_DIR/data"
FLAG="$ENABLED_DIR/${ID}_enabled"
LOCK_FILE="/tmp/autox_${ID}.lock"
PLUGIN_TARGET="$PLUGINS_DIR/autox_${ID}.sh"

SCRIPT_PATH=$(readlink -f "$0" 2>/dev/null)
[ -z "$SCRIPT_PATH" ] && SCRIPT_PATH="$0"

STAGE_WIFI="/jci/scripts/stage_wifi.sh"
START_WIFI="/jci/scripts/start_wifi.sh"
JCI_WIFIAP="/jci/scripts/jci-wifiap.sh"
WIFI_RUN_LOG="$LOG_DIR/wifi.run.log"
WPA_CONF="/tmp/wpa_supplicant.conf"
HOSTAPD_CONF="/tmp/hostapd.conf"
UDHCPD_CONF="/tmp/udhcpd.conf"
WIFI_RUNTIME_STATUS="/tmp/autox_wifi_status.json"
WIFI_WORKER_PID="/tmp/autox_wifi_worker.pid"

. /tmp/mnt/data_persist/autox/lib/autox_lib.sh
# --------------------------------------------------------------------------
# Summary: Json Escape Routine
# --------------------------------------------------------------------------
json_escape() {
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\r//g' | tr '\n' ' '
}
# --------------------------------------------------------------------------
# Summary: Sh Squote Routine
# --------------------------------------------------------------------------
sh_squote() {
    printf '%s' "$1" | sed "s/'/'\\\\''/g"
}
# --------------------------------------------------------------------------
# Summary: Wpa Escape Routine
# --------------------------------------------------------------------------
wpa_escape() {
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}
# --------------------------------------------------------------------------
# Summary: Urldecode Routine
# --------------------------------------------------------------------------
urldecode() {
    printf '%s' "$1" | tr '+' ' ' | awk '
    BEGIN {
        for (i = 0; i < 256; i++) hex[sprintf("%02X", i)] = sprintf("%c", i)
        for (i = 0; i < 256; i++) hex[sprintf("%02x", i)] = sprintf("%c", i)
    }
    {
        out = ""
        n = length($0)
        i = 1
        while (i <= n) {
            c = substr($0, i, 1)
            if (c == "%" && i + 2 <= n) {
                h = substr($0, i + 1, 2)
                if (h in hex) {
                    out = out hex[h]
                    i += 3
                    continue
                }
            }
            out = out c
            i++
        }
        printf "%s", out
    }'
}
# --------------------------------------------------------------------------
# Summary: Configuration Loader (Reads configuration settings or applies defaults)
# --------------------------------------------------------------------------
load_config() {
    WIFI_MODE="auto"
    CLIENT_SSID=""
    CLIENT_PSK=""
    CLIENT_SECURITY="WPA-PSK"
    BACKUP_SSID=""
    BACKUP_PSK=""
    BACKUP_SECURITY="WPA-PSK"
    AP_SSID="Mazda-AutoX"
    AP_PSK="mazda123"
    AP_CHANNEL="6"
    AP_IP="192.168.53.1"
    AP_NETMASK="255.255.255.0"
    ENABLE_HTTP_DASHBOARD="true"
    HTTP_PORT="8080"
    AUTO_OPEN_FIREWALL="true"

    CONFIG_FILE="$DATA_DIR/wifi.conf"

    if [ -f "$CONFIG_FILE" ]; then
        . "$CONFIG_FILE"
        if [ "$CLIENT_SSID" = "YourSSID" ] || [ "$CLIENT_PSK" = "YourHomeWiFiPassword" ]; then
            autox_log "$ID" "[WARN] Default placeholder credentials detected in $CONFIG_FILE (SSID: '$CLIENT_SSID'). Wi-Fi client mode will not work until updated."
        else
            autox_log "$ID" "[CONFIG] Successfully loaded settings from $CONFIG_FILE (WIFI_MODE=$WIFI_MODE, SSID='$CLIENT_SSID')"
        fi
    else
        autox_log "$ID" "[ERROR] Missing configuration file: $CONFIG_FILE"
        echo "[ERROR] Missing configuration file: $CONFIG_FILE"
        return 1
    fi
}
# --------------------------------------------------------------------------
# Summary: Hardware Wi-Fi Driver Initializer (Binds kernel modules & activates wlan0)
# --------------------------------------------------------------------------
init_wifi_driver() {
    if [ ! -d /sys/class/net/wlan0 ]; then
        if [ -f "$START_WIFI" ]; then
            autox_log "$ID" "[INFO] Running $START_WIFI to load kernel modules..."
            /bin/sh "$START_WIFI" >> "$WIFI_RUN_LOG" 2>&1
        else
            autox_log "$ID" "[INFO] Inserting wl12xx wireless kernel modules..."
            insmod /lib/modules/3.0.35/kernel/compat/compat.ko 2>/dev/null
            insmod /lib/modules/3.0.35/kernel/net/wireless/cfg80211.ko 2>/dev/null
            insmod /lib/modules/3.0.35/kernel/net/mac80211/mac80211.ko 2>/dev/null
            insmod /lib/modules/3.0.35/kernel/drivers/net/wireless/wl12xx/wl12xx.ko 2>/dev/null
            insmod /lib/modules/3.0.35/kernel/drivers/net/wireless/wl12xx/wl12xx_sdio.ko 2>/dev/null
        fi
    fi

    if [ -x /usr/sbin/rfkill ]; then
        rfkill unblock wifi 2>/dev/null
    fi
    ifconfig wlan0 up 2>/dev/null
}
# --------------------------------------------------------------------------
# Summary: Kill Proc Pattern Routine
# --------------------------------------------------------------------------
kill_proc_pattern() {
    _PAT="$1"
    [ -z "$_PAT" ] && return 0
    _PIDS=$(ps 2>/dev/null | awk -v pat="$_PAT" -v self="$$" '$0 ~ pat && $1 != self && $0 !~ /awk/ {print $1}')
    [ -n "$_PIDS" ] && kill -9 $_PIDS 2>/dev/null
}
# --------------------------------------------------------------------------
# Summary: Wi-Fi Daemon Teardown Routine (Terminates competing services)
# --------------------------------------------------------------------------
stop_all_wifi_daemons() {
    autox_log "$ID" "[CLEANUP] Stopping competing Wi-Fi services..."
    if [ -f "$JCI_WIFIAP" ]; then
        /bin/sh "$JCI_WIFIAP" stop >/dev/null 2>&1
    fi
    killall -9 hostapd udhcpd wpa_supplicant udhcpc 2>/dev/null
    kill_proc_pattern "jci-wifiap"
    kill_proc_pattern "wpa_supplicant"
    kill_proc_pattern "hostapd"
    sleep 1
}
# --------------------------------------------------------------------------
# Summary: Network Security & Firewall Rules Configuration Routine
# --------------------------------------------------------------------------
apply_network_security_rules() {
    if [ "$AUTO_OPEN_FIREWALL" = "true" ]; then
        autox_log "$ID" "[FIREWALL] Opening firewall for HTTP (8080) and ICMP (Ping) on all interfaces..."
        echo 0 > /proc/sys/net/ipv4/icmp_echo_ignore_all 2>/dev/null
        sysctl -w net.ipv4.icmp_echo_ignore_all=0 2>/dev/null

        iptables -I INPUT 1 -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null
        iptables -I OUTPUT 1 -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null
        iptables -I OUTPUT 1 -o wlan0 -p tcp --dport 443 -j ACCEPT 2>/dev/null
        iptables -I OUTPUT 1 -o wlan0 -p udp --dport 53 -j ACCEPT 2>/dev/null
        iptables -I OUTPUT 1 -o wlan0 -p tcp --dport 53 -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -p tcp --dport 8080 -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -p icmp -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -i wlan0 -p tcp --dport 8080 -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -i wlan0 -p icmp -j ACCEPT 2>/dev/null

        if [ -f "$ENABLED_DIR/ssh" ] || [ -f "$ENABLED_DIR/ssh_enabled" ]; then
            for port in 22 36000; do
                iptables -I INPUT 1 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
                iptables -I INPUT 1 -i wlan0 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
                iptables -I INPUT 1 -i eth0 -p tcp --dport "$port" -j ACCEPT 2>/dev/null
            done
        fi
    fi
}
# --------------------------------------------------------------------------
# Summary: Wi-Fi Station/Client Mode Handler (Connects CMU to external AP)
# --------------------------------------------------------------------------
start_client_mode() {
    if ! load_config; then
        return 1
    fi
    autox_log "$ID" "[MODE] Starting Wi-Fi Client Mode for SSID: $CLIENT_SSID"
    stop_all_wifi_daemons
    init_wifi_driver

    if [ -z "$CLIENT_SSID" ]; then
        autox_log "$ID" "[ERROR] CLIENT_SSID is empty in wifi.conf. Cannot start client mode."
        return 1
    fi

    _ESC_SSID=$(wpa_escape "$CLIENT_SSID")
    _ESC_PSK=$(wpa_escape "$CLIENT_PSK")

    if [ "$CLIENT_SECURITY" = "NONE" ] || [ "$CLIENT_SECURITY" = "OPEN" ] || [ -z "$CLIENT_PSK" ]; then
        cat << EOF > "$WPA_CONF"
ctrl_interface=/var/run/wpa_supplicant
update_config=1

network={
    ssid="$_ESC_SSID"
    key_mgmt=NONE
    priority=10
}
EOF
    else
        cat << EOF > "$WPA_CONF"
ctrl_interface=/var/run/wpa_supplicant
update_config=1

network={
    ssid="$_ESC_SSID"
    psk="$_ESC_PSK"
    key_mgmt=WPA-PSK
    priority=10
}
EOF
    fi

    if [ -n "$BACKUP_SSID" ]; then
        _ESC_B_SSID=$(wpa_escape "$BACKUP_SSID")
        _ESC_B_PSK=$(wpa_escape "$BACKUP_PSK")
        if [ "$BACKUP_SECURITY" = "NONE" ] || [ "$BACKUP_SECURITY" = "OPEN" ] || [ -z "$BACKUP_PSK" ]; then
            cat << EOF >> "$WPA_CONF"
network={
    ssid="$_ESC_B_SSID"
    key_mgmt=NONE
    priority=5
}
EOF
        else
            cat << EOF >> "$WPA_CONF"
network={
    ssid="$_ESC_B_SSID"
    psk="$_ESC_B_PSK"
    key_mgmt=WPA-PSK
    priority=5
}
EOF
        fi
    fi

    [ -f "$FLAG" ] || return 0

    wpa_supplicant -B -i wlan0 -c "$WPA_CONF" -D nl80211,wext </dev/null >> "$WIFI_RUN_LOG" 2>&1
    sleep 3
    [ -f "$FLAG" ] || { stop_all_wifi_daemons; return 0; }

    WPA_STATE=$(wpa_cli -i wlan0 status 2>/dev/null | grep "^wpa_state=" | cut -d= -f2)
    autox_log "$ID" "[WPA] Link state: $WPA_STATE"

    ifconfig wlan0 0.0.0.0
    udhcpc -i wlan0 -b -p /var/run/udhcpc.pid </dev/null >> "$WIFI_RUN_LOG" 2>&1

    DHCP_WAIT=0
    IP=""
    HAS_GW=0
    while [ $DHCP_WAIT -lt 10 ]; do
        [ -f "$FLAG" ] || { stop_all_wifi_daemons; return 0; }
        IP=$(ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{print $1}')
        HAS_GW=$(awk '$1 == "wlan0" && $2 == "00000000" {print 1; exit}' /proc/net/route 2>/dev/null)
        [ -n "$IP" ] && [ "$IP" != "0.0.0.0" ] && [ "$IP" != "$AP_IP" ] && [ "$HAS_GW" = "1" ] && break
        sleep 1
        DHCP_WAIT=$((DHCP_WAIT + 1))
    done

    apply_network_security_rules

    if ! awk '/^nameserver[ \t]+/ && $2 != "127.0.0.1" && $2 != "0.0.0.0" && $2 != "192.168.53.1" {found=1; exit} END{exit !found}' /etc/resolv.conf 2>/dev/null; then
        if ! { echo "nameserver 8.8.8.8" > /etc/resolv.conf 2>/dev/null && echo "nameserver 1.1.1.1" >> /etc/resolv.conf 2>/dev/null; }; then
            cmu_remount_rw
            echo "nameserver 8.8.8.8" > /etc/resolv.conf 2>/dev/null
            echo "nameserver 1.1.1.1" >> /etc/resolv.conf 2>/dev/null
            sync
            cmu_remount_ro
        fi
        autox_log "$ID" "[DNS] Configured Google & Cloudflare nameservers in /etc/resolv.conf"
    fi

    [ -f "$FLAG" ] || { stop_all_wifi_daemons; return 0; }
    IP=$(ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{print $1}')
    GW_HEX=$(awk '$1 == "wlan0" && $2 == "00000000" {print $3; exit}' /proc/net/route 2>/dev/null)
    DNS_LIST=$(awk '/^nameserver[ \t]+/{printf "%s ", $2}' /etc/resolv.conf 2>/dev/null)
    if [ -n "$IP" ] && [ "$IP" != "0.0.0.0" ]; then
        _J_SSID=$(json_escape "$CLIENT_SSID")
        echo "{\"state\":\"CONNECTED\",\"mode\":\"CLIENT\",\"ssid\":\"$_J_SSID\",\"ip\":\"$IP\"}" > "$WIFI_RUNTIME_STATUS" 2>/dev/null
    fi
    autox_log "$ID" "[ONLINE] Wi-Fi Client Mode Active. IP: ${IP:-Acquiring...} | GW_HEX: ${GW_HEX:-NONE} | DNS: ${DNS_LIST:-NONE}"
}
# --------------------------------------------------------------------------
# Summary: Wi-Fi SoftAP Hotspot Handler (Launches hostapd and DHCP server)
# --------------------------------------------------------------------------
start_ap_mode() {
    load_config >/dev/null 2>&1
    autox_log "$ID" "[MODE] Starting Wi-Fi Access Point Mode (SSID: $AP_SSID)"
    stop_all_wifi_daemons
    init_wifi_driver

    cat << EOF > "$HOSTAPD_CONF"
interface=wlan0
driver=nl80211
ssid=${AP_SSID:-Mazda-AutoX}
channel=${AP_CHANNEL:-6}
hw_mode=g
wpa=2
wpa_passphrase=${AP_PSK:-mazda123}
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
rsn_pairwise=CCMP
EOF

    cat << EOF > "$UDHCPD_CONF"
start 192.168.53.10
end 192.168.53.50
interface wlan0
opt subnet 255.255.255.0
opt router ${AP_IP:-192.168.53.1}
opt dns 8.8.8.8
EOF

    [ -f "$WIFI_FLAG" ] || [ -f "$FLAG" ] || return 0
    if [ -f "$JCI_WIFIAP" ]; then
        /bin/sh "$JCI_WIFIAP" start </dev/null >> "$WIFI_RUN_LOG" 2>&1 &
    else
        ifconfig wlan0 "${AP_IP:-192.168.53.1}" netmask "${AP_NETMASK:-255.255.255.0}" up
        hostapd -B "$HOSTAPD_CONF" </dev/null >> "$WIFI_RUN_LOG" 2>&1
        udhcpd "$UDHCPD_CONF" </dev/null >> "$WIFI_RUN_LOG" 2>&1
    fi

    [ -f "$FLAG" ] || { stop_all_wifi_daemons; return 0; }
    apply_network_security_rules
    _J_AP=$(json_escape "${AP_SSID:-Mazda-AutoX}")
    echo "{\"state\":\"CONNECTED\",\"mode\":\"AP\",\"ssid\":\"$_J_AP\",\"ip\":\"${AP_IP:-192.168.53.1}\"}" > "$WIFI_RUNTIME_STATUS" 2>/dev/null
    autox_log "$ID" "[ONLINE] Access Point Mode Active at ${AP_IP:-192.168.53.1}"
}
# --------------------------------------------------------------------------
# Summary: Dynamic Connection Mode Selector (Selects Client vs AP based on scan)
# --------------------------------------------------------------------------
start_auto_mode() {
    load_config
    autox_log "$ID" "[AUTO] Checking for known networks (SSID: $CLIENT_SSID)..."
    init_wifi_driver

    if [ -n "$CLIENT_SSID" ] && [ "$CLIENT_SSID" != "YourSSID" ]; then
        start_client_mode

        WAIT_TIME=0
        IP=""
        HAS_GW=0
        while [ $WAIT_TIME -lt 10 ]; do
            [ -f "$FLAG" ] || { stop_all_wifi_daemons; return 0; }
            IP=$(ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{print $1}')
            HAS_GW=$(awk '$1 == "wlan0" && $2 == "00000000" {print 1; exit}' /proc/net/route 2>/dev/null)
            if [ -n "$IP" ] && [ "$IP" != "0.0.0.0" ] && [ "$IP" != "$AP_IP" ] && [ "$HAS_GW" = "1" ]; then
                break
            fi
            sleep 1
            WAIT_TIME=$((WAIT_TIME + 1))
        done

        [ -f "$FLAG" ] || { stop_all_wifi_daemons; return 0; }
        if [ -n "$IP" ] && [ "$IP" != "0.0.0.0" ] && [ "$IP" != "$AP_IP" ]; then
            _J_SSID=$(json_escape "$CLIENT_SSID")
            echo "{\"state\":\"CONNECTED\",\"mode\":\"CLIENT\",\"ssid\":\"$_J_SSID\",\"ip\":\"$IP\"}" > "$WIFI_RUNTIME_STATUS" 2>/dev/null
            autox_log "$ID" "[AUTO] Connected to router ($IP, gw=${HAS_GW:-0}). Retaining Client Mode."
            return 0
        fi
    fi

    [ -f "$FLAG" ] || { stop_all_wifi_daemons; return 0; }
    autox_log "$ID" "[AUTO] Router not reachable or unconfigured. Falling back to AP / Wireless AA Mode."
    start_ap_mode
}
# --------------------------------------------------------------------------
# Summary: Master Wi-Fi Service Initializer (Dispatches to selected operational mode)
# --------------------------------------------------------------------------
start_wifi_service() {
    if ! load_config; then
        echo '{"state":"FAILED","mode":"NONE","message":"Missing wifi.conf configuration"}' > "$WIFI_RUNTIME_STATUS" 2>/dev/null
        return 1
    fi
    case "$WIFI_MODE" in
        client) start_client_mode ;;
        ap)     start_ap_mode ;;
        auto|*) start_auto_mode ;;
    esac
}
# --------------------------------------------------------------------------
# Summary: Scan Routine
# --------------------------------------------------------------------------
do_scan() {
    WAS_AP="false"
    init_wifi_driver >/dev/null 2>&1

    if pidof hostapd >/dev/null 2>&1 || grep -q '"mode":"AP"' "$WIFI_RUNTIME_STATUS" 2>/dev/null; then
        WAS_AP="true"
        autox_log "$ID" "[SCAN] Pausing SoftAP temporarily to scan nearby networks..."
        killall -9 hostapd udhcpd 2>/dev/null
        kill_proc_pattern "hostapd"
        ifconfig wlan0 up 2>/dev/null
        sleep 1
    fi

    _RAW_SCAN=""
    if command -v iwlist >/dev/null 2>&1; then
        _RAW_SCAN=$(iwlist wlan0 scanning 2>/dev/null)
        _SCAN_JSON=$(printf '%s\n' "$_RAW_SCAN" | awk '
        function jesc(s) { gsub(/\\/, "\\\\", s); gsub(/"/, "\\\"", s); return s }
# --------------------------------------------------------------------------
# Summary: Emit Routine
# --------------------------------------------------------------------------
emit() {
            if (ssid != "" && ssid !~ /\\x00/ && !(ssid in seen)) {
                seen[ssid] = 1
                sec = has_enc ? (has_wpa2 ? "WPA2" : "WPA-PSK") : "OPEN"
                sig = (signal != "") ? signal : "--"
                if (cnt > 0) printf ","
                printf "{\"ssid\":\"%s\",\"signal\":\"%s\",\"security\":\"%s\"}", jesc(ssid), jesc(sig), sec
                cnt++
            }
        }
        BEGIN { cnt = 0; ssid = ""; signal = ""; has_enc = 0; has_wpa2 = 0 }
        /Cell [0-9]+/ {
            emit()
            ssid = ""; signal = ""; has_enc = 0; has_wpa2 = 0
        }
        /ESSID:"/ {
            line = $0
            sub(/.*ESSID:"/, "", line)
            sub(/"[ \t]*$/, "", line)
            ssid = line
        }
        /Signal level=/ {
            line = $0
            sub(/.*Signal level=/, "", line)
            sub(/[ \t]+.*$/, "", line)
            signal = line " dBm"
            gsub(/ dBm dBm/, " dBm", signal)
        }
        /Encryption key:on/ { has_enc = 1 }
        /WPA2|IEEE 802\.11i/ { has_enc = 1; has_wpa2 = 1 }
        /WPA Version/ { has_enc = 1 }
        END { emit() }
        ')
    elif command -v iw >/dev/null 2>&1; then
        _RAW_SCAN=$(iw dev wlan0 scan 2>/dev/null)
        _SCAN_JSON=$(printf '%s\n' "$_RAW_SCAN" | awk '
        function jesc(s) { gsub(/\\/, "\\\\", s); gsub(/"/, "\\\"", s); return s }
        function emit() {
            if (ssid != "" && !(ssid in seen)) {
                seen[ssid] = 1
                sec = has_wpa2 ? "WPA2" : (has_enc ? "WPA-PSK" : "OPEN")
                sig = (signal != "") ? signal : "--"
                if (cnt > 0) printf ","
                printf "{\"ssid\":\"%s\",\"signal\":\"%s\",\"security\":\"%s\"}", jesc(ssid), jesc(sig), sec
                cnt++
            }
        }
        BEGIN { cnt = 0; ssid = ""; signal = ""; has_enc = 0; has_wpa2 = 0 }
        /^BSS / { emit(); ssid = ""; signal = ""; has_enc = 0; has_wpa2 = 0 }
        /SSID:/ { sub(/^[ \t]*SSID:[ \t]*/, ""); ssid = $0 }
        /signal:/ { sub(/^[ \t]*signal:[ \t]*/, ""); sub(/[ \t]*$/, ""); signal = $0 }
        /RSN:/ { has_enc = 1; has_wpa2 = 1 }
        /WPA:|Privacy/ { has_enc = 1 }
        END { emit() }
        ')
    else
        _SCAN_JSON=""
    fi

    echo "{\"status\":\"OK\",\"was_ap\":$WAS_AP,\"networks\":[$_SCAN_JSON]}"
}
# --------------------------------------------------------------------------
# Summary: Restore Ap Routine
# --------------------------------------------------------------------------
do_restore_ap() {
    if [ -f "$FLAG" ]; then
        load_config >/dev/null 2>&1
        if [ "$WIFI_MODE" = "ap" ] || [ "$WIFI_MODE" = "auto" ]; then
            if ! pidof wpa_supplicant >/dev/null 2>&1 && ! pidof hostapd >/dev/null 2>&1; then
                /bin/sh "$PLUGIN_TARGET" ap </dev/null >/dev/null 2>&1 &
                echo '{"status":"OK","restored":true}'
                return 0
            fi
        fi
    fi
    echo '{"status":"OK","restored":false}'
}
# --------------------------------------------------------------------------
# Summary: Get Config Routine
# --------------------------------------------------------------------------
do_get_config() {
    load_config >/dev/null 2>&1
    _CUR_STAT=$(get_wifi_status --raw 2>/dev/null)
    _CUR_IP=$(ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{print $1}')

    _J_STAT=$(json_escape "${_CUR_STAT:-DISABLED}")
    _J_MODE=$(json_escape "${WIFI_MODE:-auto}")
    _J_SSID=$(json_escape "$CLIENT_SSID")
    _J_PSK=$(json_escape "$CLIENT_PSK")
    _J_SEC=$(json_escape "${CLIENT_SECURITY:-WPA-PSK}")
    _J_AP=$(json_escape "${AP_SSID:-Mazda-AutoX}")
    _J_IP=$(json_escape "$_CUR_IP")

    echo "{\"status\":\"$_J_STAT\",\"wifi_mode\":\"$_J_MODE\",\"client_ssid\":\"$_J_SSID\",\"client_psk\":\"$_J_PSK\",\"client_security\":\"$_J_SEC\",\"ap_ssid\":\"$_J_AP\",\"ip\":\"$_J_IP\"}"
}
# --------------------------------------------------------------------------
# Summary: Set Config Routine
# --------------------------------------------------------------------------
do_set_config() {
    _POST_RAW=$(cat 2>/dev/null)
    load_config >/dev/null 2>&1

    _NEW_MODE="$WIFI_MODE"
    _NEW_SSID="$CLIENT_SSID"
    _NEW_PSK="$CLIENT_PSK"
    _NEW_SEC="$CLIENT_SECURITY"
    _DO_CONNECT="false"

    _OLD_IFS="$IFS"
    IFS='&'
    for _PAIR in $_POST_RAW; do
        _KEY="${_PAIR%%=*}"
        _VAL="${_PAIR#*=}"
        [ "$_PAIR" = "$_KEY" ] && _VAL=""
        _VAL_DEC=$(urldecode "$_VAL")
        case "$_KEY" in
            wifi_mode)       _NEW_MODE="$_VAL_DEC" ;;
            client_ssid)     _NEW_SSID="$_VAL_DEC" ;;
            client_psk)      _NEW_PSK="$_VAL_DEC" ;;
            client_security) _NEW_SEC="$_VAL_DEC" ;;
            connect)         _DO_CONNECT="$_VAL_DEC" ;;
        esac
    done
    IFS="$_OLD_IFS"

    case "$_NEW_MODE" in
        auto|client|ap) ;;
        *) _NEW_MODE="auto" ;;
    esac

    case "$_NEW_SEC" in
        NONE|OPEN|none|open) _NEW_SEC="NONE" ;;
        *) _NEW_SEC="WPA-PSK" ;;
    esac

    mkdir -p "$DATA_DIR" 2>/dev/null
    _TMP_CONF="/tmp/autox_wifi_conf_$$.tmp"

    _Q_MODE=$(sh_squote "$_NEW_MODE")
    _Q_SSID=$(sh_squote "$_NEW_SSID")
    _Q_PSK=$(sh_squote "$_NEW_PSK")
    _Q_SEC=$(sh_squote "$_NEW_SEC")
    _Q_B_SSID=$(sh_squote "$BACKUP_SSID")
    _Q_B_PSK=$(sh_squote "$BACKUP_PSK")
    _Q_B_SEC=$(sh_squote "${BACKUP_SECURITY:-WPA-PSK}")
    _Q_AP_SSID=$(sh_squote "${AP_SSID:-Mazda-AutoX}")
    _Q_AP_PSK=$(sh_squote "${AP_PSK:-mazda123}")
    _Q_AP_CH=$(sh_squote "${AP_CHANNEL:-6}")
    _Q_AP_IP=$(sh_squote "${AP_IP:-192.168.53.1}")
    _Q_AP_MASK=$(sh_squote "${AP_NETMASK:-255.255.255.0}")
    _Q_HTTP_EN=$(sh_squote "${ENABLE_HTTP_DASHBOARD:-true}")
    _Q_HTTP_PT=$(sh_squote "${HTTP_PORT:-8080}")
    _Q_FW=$(sh_squote "${AUTO_OPEN_FIREWALL:-true}")

    cat << EOF > "$_TMP_CONF"
# AutoX Wi-Fi Configuration File
WIFI_MODE='$_Q_MODE'
CLIENT_SSID='$_Q_SSID'
CLIENT_PSK='$_Q_PSK'
CLIENT_SECURITY='$_Q_SEC'
BACKUP_SSID='$_Q_B_SSID'
BACKUP_PSK='$_Q_B_PSK'
BACKUP_SECURITY='$_Q_B_SEC'
AP_SSID='$_Q_AP_SSID'
AP_PSK='$_Q_AP_PSK'
AP_CHANNEL='$_Q_AP_CH'
AP_IP='$_Q_AP_IP'
AP_NETMASK='$_Q_AP_MASK'
ENABLE_HTTP_DASHBOARD='$_Q_HTTP_EN'
HTTP_PORT='$_Q_HTTP_PT'
AUTO_OPEN_FIREWALL='$_Q_FW'
EOF

    if ! cp -f "$_TMP_CONF" "$DATA_DIR/wifi.conf" 2>/dev/null; then
        rm -f "$_TMP_CONF" 2>/dev/null
        echo '{"status":"ERROR","saved":false,"message":"Failed writing wifi.conf"}'
        return 1
    fi
    rm -f "$_TMP_CONF" 2>/dev/null
    chmod 644 "$DATA_DIR/wifi.conf" 2>/dev/null
    sync
    autox_log "$ID" "[CONFIG] Updated wifi.conf (WIFI_MODE=$_NEW_MODE, CLIENT_SSID=$_NEW_SSID, CLIENT_SECURITY=$_NEW_SEC, connect=$_DO_CONNECT)"

    if [ "$_DO_CONNECT" = "true" ] || [ "$_DO_CONNECT" = "1" ]; then
        do_enable >/dev/null 2>&1
    fi

    _CUR_STAT=$(get_wifi_status --raw 2>/dev/null)
    _J_STAT=$(json_escape "${_CUR_STAT:-DISABLED}")
    _J_MODE=$(json_escape "$_NEW_MODE")
    _J_SSID=$(json_escape "$_NEW_SSID")
    _CONN_BOOL="false"
    _MSG="Saved wifi.conf."
    if [ "$_DO_CONNECT" = "true" ] || [ "$_DO_CONNECT" = "1" ]; then
        _CONN_BOOL="true"
        _MSG="Saved wifi.conf and connecting..."
    fi

    echo "{\"status\":\"$_J_STAT\",\"saved\":true,\"connect\":$_CONN_BOOL,\"wifi_mode\":\"$_J_MODE\",\"client_ssid\":\"$_J_SSID\",\"message\":\"$_MSG\"}"
}
# --------------------------------------------------------------------------
# Summary: Wi-Fi State & Interface Query Routine (Outputs raw status or RFC 8259 JSON)
# --------------------------------------------------------------------------
get_wifi_status() {
    IS_RUNNING="DISABLED"
    CURRENT_MODE="NONE"
    CURRENT_SSID=""
    CURRENT_IP=""

    if [ ! -f "$FLAG" ]; then
        if [ "$1" = "--raw" ] || [ "$1" = "status" ]; then
            echo "DISABLED"
            return 0
        fi
    else
        load_config >/dev/null 2>&1
        CURRENT_IP=$(ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{print $1}')
        if [ -f "$WIFI_RUNTIME_STATUS" ]; then
            if grep -q '"state":"CONNECTED"' "$WIFI_RUNTIME_STATUS" 2>/dev/null; then
                IS_RUNNING="ENABLED"
            elif grep -q '"state":"FAILED"' "$WIFI_RUNTIME_STATUS" 2>/dev/null; then
                IS_RUNNING="DISABLED"
            elif grep -q '"state":"CONNECTING"' "$WIFI_RUNTIME_STATUS" 2>/dev/null; then
                IS_RUNNING="CONNECTING"
            fi
        fi

        if [ "$IS_RUNNING" = "DISABLED" ]; then
            if pidof wpa_supplicant >/dev/null 2>&1; then
                IS_RUNNING="ENABLED"
                CURRENT_MODE="CLIENT"
                CURRENT_SSID=$(wpa_cli -i wlan0 status 2>/dev/null | grep "^ssid=" | cut -d= -f2)
            elif pidof hostapd >/dev/null 2>&1; then
                IS_RUNNING="ENABLED"
                CURRENT_MODE="AP"
                CURRENT_SSID="$AP_SSID"
            elif ! grep -q '"state":"FAILED"' "$WIFI_RUNTIME_STATUS" 2>/dev/null; then
                IS_RUNNING="CONNECTING"
            fi
        fi
    fi

    if [ "$1" = "--raw" ] || [ "$1" = "status" ]; then
        echo "$IS_RUNNING"
    elif [ "$1" = "--json" ] || [ "$1" = "json" ]; then
        _J_TITLE=$(json_escape "$TITLE")
        _J_SSID=$(json_escape "$CURRENT_SSID")
        cat << EOF
{
  "plugin": "autox_wifi",
  "name": "$_J_TITLE",
  "status": "$IS_RUNNING",
  "enabled": $([ "$IS_RUNNING" = "ENABLED" ] && echo "true" || echo "false"),
  "mode": "$CURRENT_MODE",
  "ssid": "$_J_SSID",
  "ip": "${CURRENT_IP:-none}",
  "version": "$VERSION"
}
EOF
    else
        echo "[AutoX Wi-Fi] Status: $IS_RUNNING | Mode: $CURRENT_MODE | SSID: $CURRENT_SSID | IP: ${CURRENT_IP:-none}"
    fi
}
# --------------------------------------------------------------------------
# Summary: First-Run Deployment Routine (NAND Staging & Permission Hardening)
# --------------------------------------------------------------------------
do_install() {
    acquire_lock
    autox_log "$ID" "[START] $TITLE v$VERSION Installation Initiated"

    cmu_remount_rw
    mazda_watchdog_disable
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR" "$AUTOX_DIR/www/plugins/ui" 2>/dev/null

    if [ ! -f "$DATA_DIR/wifi.conf" ]; then
        if [ -n "$AUTOX_USB_ROOT" ] && [ -f "$AUTOX_USB_ROOT/_autox/data/wifi.conf" ]; then
            cp -f "$AUTOX_USB_ROOT/_autox/data/wifi.conf" "$DATA_DIR/wifi.conf"
            chmod 644 "$DATA_DIR/wifi.conf" 2>/dev/null
            autox_log "$ID" "[FILE] Deployed wifi.conf from USB to flash"
        elif [ -f "$PLUGINS_DIR/wifi.conf" ]; then
            cp -f "$PLUGINS_DIR/wifi.conf" "$DATA_DIR/wifi.conf"
            chmod 644 "$DATA_DIR/wifi.conf" 2>/dev/null
            autox_log "$ID" "[FILE] Deployed wifi.conf from package to flash"
        else
            autox_log "$ID" "[WARN] No wifi.conf found on USB at _autox/data/wifi.conf or in plugin package"
        fi
    fi
    rm -f "$PLUGINS_DIR/wifi.conf" 2>/dev/null

    if [ -f "$PLUGINS_DIR/ui/wifi.js" ]; then
        cp -f "$PLUGINS_DIR/ui/wifi.js" "$AUTOX_DIR/www/plugins/ui/wifi.js" 2>/dev/null
        chmod 644 "$AUTOX_DIR/www/plugins/ui/wifi.js" 2>/dev/null
    fi
    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock

    case "$(echo "$INSTALL_STATE" | tr '[:upper:]' '[:lower:]')" in
        "enabled"|"enable"|"1"|"true")
            autox_log "$ID" "INSTALL_STATE is 'enabled'. Activating Wi-Fi services now..."
            do_enable
            ;;
        "disabled"|"disable"|"0"|"false"|*)
            autox_log "$ID" "INSTALL_STATE is 'disabled'. Plugin deployed in dormant state."
            rm -f "$FLAG" 2>/dev/null
            echo "Wi-Fi Service: DISABLED (stage_wifi.sh hook removed)"
            ;;
    esac
}
# --------------------------------------------------------------------------
# Summary: In-Place Upgrade Handler (Version Matching & Safe State Preservation)
# --------------------------------------------------------------------------
do_reinstall() {
    FORCE=0
    [ "$1" = "--force" ] || [ "$2" = "--force" ] && FORCE=1

    if [ "$SCRIPT_PATH" = "$PLUGIN_TARGET" ]; then
        autox_log "$ID" "[ERROR] Cannot reinstall directly from installed target path $PLUGIN_TARGET."
        return 1
    fi

    CUR_VER="0"
    if [ -f "$PLUGIN_TARGET" ]; then
        CUR_VER=$("/bin/sh" "$PLUGIN_TARGET" version 2>/dev/null)
        [ -z "$CUR_VER" ] && CUR_VER="0"
    fi

    if [ "$CUR_VER" = "$VERSION" ] && [ $FORCE -eq 0 ]; then
        autox_log "$ID" "[SKIP] $ID already at v$VERSION. Skipping in-place rewrite."
        return 0
    fi

    WAS_ENABLED=0
    [ -f "$FLAG" ] && WAS_ENABLED=1

    if ! /bin/sh "$PLUGIN_TARGET" disable >/dev/null 2>&1; then
        autox_log "$ID" "[WARN] Prior instance returned non-zero on disable; continuing upgrade."
    fi

    if ! cp -f "$SCRIPT_PATH" "$PLUGIN_TARGET"; then
        autox_log "$ID" "[ERROR] Failed copying $SCRIPT_PATH to $PLUGIN_TARGET."
        return 1
    fi
    chmod 755 "$PLUGIN_TARGET" 2>/dev/null
    sync

    if ! /bin/sh "$PLUGIN_TARGET" install; then
        autox_log "$ID" "[ERROR] Failed installing upgraded $ID payload."
        return 1
    fi

    if [ $WAS_ENABLED -eq 1 ]; then
        if ! /bin/sh "$PLUGIN_TARGET" enable --staged; then
            autox_log "$ID" "[ERROR] Upgraded $ID failed staged re-enable."
            return 1
        fi
    fi
    autox_log "$ID" "[REINSTALL] Successfully updated $ID to v$VERSION."
}
# --------------------------------------------------------------------------
# Summary: Remove Hooks Routine
# --------------------------------------------------------------------------
remove_hooks() {
    TMP_STRIP="/tmp/autox_${ID}_strip.tmp"
    TMP_FILE="/tmp/autox_${ID}_rm.tmp"

    if [ -s "$STAGE_WIFI" ]; then
        if grep -q '# === AutoX wifi Insertion Hook ===' "$STAGE_WIFI" 2>/dev/null; then
            if ! grep -q '# === AutoX wifi Insertion Hook End ===' "$STAGE_WIFI" 2>/dev/null; then
                autox_log "$ID" "[ERROR] Unclosed wifi hook marker in stage_wifi.sh; aborting teardown."
                return 1
            fi
            sed '/# === AutoX wifi Insertion Hook ===/,/# === AutoX wifi Insertion Hook End ===/d' "$STAGE_WIFI" > "$TMP_STRIP" 2>/dev/null
            awk '{ if (/^[ \t\r]*$/) { buf = buf "\n" } else { printf "%s%s\n", buf, $0; buf = "" } }' "$TMP_STRIP" > "$TMP_FILE" 2>/dev/null
            if [ $? -eq 0 ] && [ -s "$TMP_FILE" ]; then
                cp -f "$TMP_FILE" "$STAGE_WIFI"
                rm -f "$TMP_STRIP" "$TMP_FILE"
                autox_log "$ID" "[HOOK] Removed wifi hook & trailing blank lines from stage_wifi.sh"
            else
                rm -f "$TMP_STRIP" "$TMP_FILE"
                autox_log "$ID" "[ERROR] Failed staging clean stage_wifi.sh in /tmp"
                return 1
            fi
        fi

        if grep -q '# === AutoX Wi-Fi Boot Hook ===' "$STAGE_WIFI" 2>/dev/null; then
            if ! grep -q '# === AutoX Wi-Fi Boot Hook End ===' "$STAGE_WIFI" 2>/dev/null; then
                autox_log "$ID" "[ERROR] Unclosed legacy Wi-Fi Boot Hook marker in stage_wifi.sh; aborting teardown."
                return 1
            fi
            sed '/# === AutoX Wi-Fi Boot Hook ===/,/# === AutoX Wi-Fi Boot Hook End ===/d' "$STAGE_WIFI" > "$TMP_STRIP" 2>/dev/null
            awk '{ if (/^[ \t\r]*$/) { buf = buf "\n" } else { printf "%s%s\n", buf, $0; buf = "" } }' "$TMP_STRIP" > "$TMP_FILE" 2>/dev/null
            if [ $? -eq 0 ] && [ -s "$TMP_FILE" ]; then
                cp -f "$TMP_FILE" "$STAGE_WIFI"
                rm -f "$TMP_STRIP" "$TMP_FILE"
                autox_log "$ID" "[HOOK] Removed legacy v0.10 Wi-Fi Boot Hook from stage_wifi.sh"
            else
                rm -f "$TMP_STRIP" "$TMP_FILE"
                autox_log "$ID" "[ERROR] Failed staging legacy stage_wifi.sh cleanup in /tmp"
                return 1
            fi
        fi
    fi

    LEGACY_NET="/jci/scripts/start_network.sh"
    if [ -s "$LEGACY_NET" ] && grep -q '# === AutoX Wi-Fi Boot Hook ===' "$LEGACY_NET" 2>/dev/null; then
        if grep -q '# === AutoX Wi-Fi Boot Hook End ===' "$LEGACY_NET" 2>/dev/null; then
            sed '/# === AutoX Wi-Fi Boot Hook ===/,/# === AutoX Wi-Fi Boot Hook End ===/d' "$LEGACY_NET" > "$TMP_STRIP" 2>/dev/null
            awk '{ if (/^[ \t\r]*$/) { buf = buf "\n" } else { printf "%s%s\n", buf, $0; buf = "" } }' "$TMP_STRIP" > "$TMP_FILE" 2>/dev/null
            if [ $? -eq 0 ] && [ -s "$TMP_FILE" ]; then
                cp -f "$TMP_FILE" "$LEGACY_NET"
                autox_log "$ID" "[HOOK] Removed legacy Wi-Fi Boot Hook from start_network.sh"
            fi
            rm -f "$TMP_STRIP" "$TMP_FILE"
        fi
    fi
    return 0
}
# --------------------------------------------------------------------------
# Summary: Persistent Service Activation (Hook Injection & Recovery Suppression)
# --------------------------------------------------------------------------
do_enable() {
    acquire_lock
    autox_log "$ID" "[START] Enabling $TITLE v$VERSION"

    cmu_remount_rw
    mazda_watchdog_disable
    mkdir -p "$PLUGINS_DIR" "$ENABLED_DIR" "$LOG_DIR" "$DATA_DIR" 2>/dev/null

    if ! remove_hooks; then
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    if [ ! -f "$STAGE_WIFI" ]; then
        printf '#!/bin/sh\n' > "$STAGE_WIFI"
    fi

    printf '# === AutoX %s Insertion Hook === v%s\n' "$ID" "${VERSION#v}" >> "$STAGE_WIFI"
    cat << 'EOF' >> "$STAGE_WIFI"
if [ -f /tmp/mnt/data_persist/autox/plugins/enabled/wifi_enabled ] && [ -f /tmp/mnt/data_persist/autox/plugins/autox_wifi.sh ]; then
    /bin/sh /tmp/mnt/data_persist/autox/plugins/autox_wifi.sh start > /tmp/mnt/data_persist/autox/logs/wifi.run.log 2>&1 &
fi
# === AutoX wifi Insertion Hook End ===
EOF

    _HOOK_START=$(grep -c '# === AutoX wifi Insertion Hook ===' "$STAGE_WIFI" 2>/dev/null)
    _HOOK_END=$(grep -c '# === AutoX wifi Insertion Hook End ===' "$STAGE_WIFI" 2>/dev/null)
    if [ $? -ne 0 ] || [ "$_HOOK_START" != "1" ] || [ "$_HOOK_END" != "1" ]; then
        autox_log "$ID" "[ERROR] Failed injecting or verifying single wifi boot hook in stage_wifi.sh"
        mazda_watchdog_enable
        cmu_remount_ro
        release_lock
        return 1
    fi

    chmod 755 "$STAGE_WIFI" 2>/dev/null
    touch "$FLAG" 2>/dev/null
    echo '{"state":"CONNECTING","mode":"SEARCHING","message":"Connecting to Wi-Fi..."}' > "$WIFI_RUNTIME_STATUS" 2>/dev/null
    autox_log "$ID" "[HOOK] Injected single wifi boot hook into stage_wifi.sh"

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock

    if [ "$1" != "--staged" ]; then
        if [ -f "$WIFI_WORKER_PID" ]; then
            _OLD_WPID=$(cat "$WIFI_WORKER_PID" 2>/dev/null)
            [ -n "$_OLD_WPID" ] && kill -9 "$_OLD_WPID" 2>/dev/null
            rm -f "$WIFI_WORKER_PID" 2>/dev/null
        fi
        /bin/sh "$PLUGIN_TARGET" start </dev/null >/dev/null 2>&1 &
        echo $! > "$WIFI_WORKER_PID" 2>/dev/null
    fi

    if [ "$REBOOT_REQUIRED" = "true" ]; then
        autox_log "$ID" "[REBOOT] $TITLE requires CMU reboot to take effect."
        echo "SUCCESS: $TITLE enabled. [REBOOT_REQUIRED=true]"
    else
        echo "SUCCESS: $TITLE enabled."
    fi
    return 0
}
# --------------------------------------------------------------------------
# Summary: Service Deactivation (Process Termination & Hook Deletion)
# --------------------------------------------------------------------------
do_disable() {
    acquire_lock
    autox_log "$ID" "[START] Disabling $TITLE v$VERSION"

    rm -f "$FLAG" "$WIFI_RUNTIME_STATUS" 2>/dev/null
    if [ -f "$WIFI_WORKER_PID" ]; then
        _WPID=$(cat "$WIFI_WORKER_PID" 2>/dev/null)
        [ -n "$_WPID" ] && kill -9 "$_WPID" 2>/dev/null
        rm -f "$WIFI_WORKER_PID" 2>/dev/null
    fi
    kill_proc_pattern "autox_wifi\.sh start"

    cmu_remount_rw
    mazda_watchdog_disable
    stop_all_wifi_daemons
    remove_hooks
    rm -f "$FLAG" "$WIFI_RUNTIME_STATUS" 2>/dev/null

    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: $TITLE disabled."
    return 0
}
# --------------------------------------------------------------------------
# Summary: Total Plugin Purge (Hook Removal, Process Kill & Target Script Deletion)
# --------------------------------------------------------------------------
do_uninstall() {
    acquire_lock
    autox_log "$ID" "[START] Uninstalling $TITLE v$VERSION"

    cmu_remount_rw
    mazda_watchdog_disable
    stop_all_wifi_daemons
    remove_hooks

    rm -f "$FLAG" "$WIFI_RUNTIME_STATUS" "$WIFI_WORKER_PID" "$DATA_DIR/wifi.conf" "$PLUGINS_DIR/ui/wifi.js" "$AUTOX_DIR/www/plugins/ui/wifi.js" "$LOCK_FILE" "$PLUGIN_TARGET" 2>/dev/null
    sync
    mazda_watchdog_enable
    cmu_remount_ro
    release_lock
    echo "SUCCESS: Plugin uninstalled."
    return 0
}
# --------------------------------------------------------------------------
# Summary: Master CLI Action Router & Framework Dispatcher
# --------------------------------------------------------------------------
execute_plugin() {
    _ACTION="$1"
    case "$_ACTION" in
        "version"|"--version")
            echo "$VERSION"
            ;;
        "start"|"--start")
            autox_log "$ID" "Started do_start event"
            start_wifi_service
            ;;
        "stop"|"--stop")
            autox_log "$ID" "Started do_stop event"
            stop_all_wifi_daemons
            ;;
        "client"|"--client")
            autox_log "$ID" "Started do_client event"
            start_client_mode
            ;;
        "ap"|"--ap")
            autox_log "$ID" "Started do_ap event"
            start_ap_mode
            ;;
        "scan"|"--scan")
            do_scan
            ;;
        "get_config"|"--get_config")
            do_get_config
            ;;
        "set_config"|"--set_config")
            do_set_config
            ;;
        "restore_ap"|"--restore_ap")
            do_restore_ap
            ;;
        "install"|"--install"|"-i")
            do_install
            ;;
        "reinstall")
            do_reinstall "$2"
            ;;
        "toggle"|"--toggle")
            if [ -f "$FLAG" ]; then
                execute_plugin "disable"
            else
                execute_plugin "enable"
            fi
            ;;
        "enable"|"--enable")
            do_enable "$2"
            ;;
        "disable"|"--disable")
            do_disable
            ;;
        "shutdown"|"--shutdown")
            autox_log "$ID" "[SHUTDOWN] Stopping Wi-Fi daemons immediately..."
            stop_all_wifi_daemons
            ;;
        "uninstall"|"--uninstall"|"-u")
            do_uninstall
            ;;
        "status"|"--status"|"-s")
            get_wifi_status --raw
            ;;
        "raw"|"--raw")
            get_wifi_status --raw
            ;;
        "meta"|"--meta"|"info"|"--info")
            _STAT=$(get_wifi_status --raw 2>/dev/null)
            echo "{\"id\":\"$ID\",\"title\":\"$TITLE\",\"subtitle\":\"$SUBTITLE\",\"author\":\"$AUTHOR\",\"category\":\"$CATEGORY\",\"order\":$ORDER,\"version\":\"$VERSION\",\"status\":\"$_STAT\",\"show_in_gui\":$SHOW_IN_GUI,\"install_state\":\"$INSTALL_STATE\",\"reboot_required\":$REBOOT_REQUIRED,\"long_press\":$LONG_PRESS}"
            ;;
        "json"|"--json")
            get_wifi_status --json
            ;;
        "help"|"--help"|"-h"|*)
            autox_log "$ID" "Started do_help/usage event"
            echo "$TITLE v$VERSION"
            echo "Usage: autox_${ID}.sh [start|stop|client|ap|scan|get_config|set_config|restore_ap|install|reinstall|toggle|enable|disable|shutdown|uninstall|status|raw|meta|json|help]"
            ;;
    esac
}

execute_plugin "$@"
